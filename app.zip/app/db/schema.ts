import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  boolean,
  int,
  bigint,
  date,
  unique,
} from "drizzle-orm/mysql-core";

// Users table - extends auth user with game profile
export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  nickname: varchar("nickname", { length: 16 }),
  gameAvatar: varchar("game_avatar", { length: 255 }),
  currentRoomCode: varchar("current_room_code", { length: 6 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Rooms table
export const rooms = mysqlTable("rooms", {
  code: varchar("code", { length: 6 }).primaryKey(),
  name: varchar("name", { length: 50 }).notNull(),
  hostId: bigint("host_id", { mode: "number", unsigned: true }).notNull(),
  maxPlayers: int("max_players").default(20).notNull(),
  extractAgent: boolean("extract_agent").default(false),
  agentPerPosition: int("agent_per_position").default(1),
  extractRule: boolean("extract_rule").default(false),
  ruleGroupId: bigint("rule_group_id", { mode: "number", unsigned: true }),
  undercoverEnabled: boolean("undercover_enabled").default(false),
  undercoverPerTeam: int("undercover_per_team").default(1),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull().$onUpdate(() => new Date()),
});

export type Room = typeof rooms.$inferSelect;

// Room players table
export const roomPlayers = mysqlTable("room_players", {
  id: serial("id").primaryKey(),
  roomCode: varchar("room_code", { length: 6 }).notNull(),
  userId: bigint("user_id", { mode: "number", unsigned: true }).notNull(),
  team: mysqlEnum("team", ["defender", "attacker", "spectator"]).default("spectator").notNull(),
  position: int("position"),
  assignedAgentId: bigint("assigned_agent_id", { mode: "number", unsigned: true }),
  assignedRuleId: bigint("assigned_rule_id", { mode: "number", unsigned: true }),
  isUndercover: boolean("is_undercover").default(false),
  isAdmin: boolean("is_admin").default(false),
  joinedAt: timestamp("joined_at").defaultNow().notNull(),
}, (table) => [
  unique("room_user_unique").on(table.roomCode, table.userId),
]);

export type RoomPlayer = typeof roomPlayers.$inferSelect;

// Agents (Valorant characters) table
export const agents = mysqlTable("agents", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 50 }).notNull(),
  nameEn: varchar("name_en", { length: 50 }).notNull(),
  role: mysqlEnum("role", ["duelist", "controller", "initiator", "sentinel"]).notNull(),
  avatar: varchar("avatar", { length: 255 }),
  color: varchar("color", { length: 7 }).default("#FF4655"),
});

export type Agent = typeof agents.$inferSelect;

// Rule groups table
export const ruleGroups = mysqlTable("rule_groups", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 50 }).notNull(),
  userId: bigint("user_id", { mode: "number", unsigned: true }),
  isDefault: boolean("is_default").default(false),
});

export type RuleGroup = typeof ruleGroups.$inferSelect;

// Rules table
export const rules = mysqlTable("rules", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  content: text("content").notNull(),
  groupId: bigint("group_id", { mode: "number", unsigned: true }).notNull(),
  userId: bigint("user_id", { mode: "number", unsigned: true }),
  isPreset: boolean("is_preset").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Rule = typeof rules.$inferSelect;

// Hidden groups table (user-hidden preset groups)
export const hiddenGroups = mysqlTable("hidden_groups", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number", unsigned: true }).notNull(),
  groupId: bigint("group_id", { mode: "number", unsigned: true }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => [
  unique("hidden_group_unique").on(table.userId, table.groupId),
]);

export type HiddenGroup = typeof hiddenGroups.$inferSelect;

// Bookings table
export const bookings = mysqlTable("bookings", {
  id: serial("id").primaryKey(),
  roomCode: varchar("room_code", { length: 6 }).notNull(),
  userId: bigint("user_id", { mode: "number", unsigned: true }).notNull(),
  timeSlot: varchar("time_slot", { length: 11 }).notNull(),
  bookingDate: date("booking_date").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => [
  unique("booking_unique").on(table.roomCode, table.userId, table.timeSlot, table.bookingDate),
]);

export type Booking = typeof bookings.$inferSelect;
