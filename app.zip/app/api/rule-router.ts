import { z } from "zod";
import { createRouter, authedQuery, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { rules, ruleGroups, roomPlayers, rooms, hiddenGroups } from "@db/schema";
import { eq, and, like, or, isNull, ne, inArray, notInArray } from "drizzle-orm";
import { TRPCError } from "@trpc/server";

export const ruleRouter = createRouter({
  listGroups: publicQuery.query(async ({ ctx }) => {
    const db = getDb();

    if (ctx.user) {
      // Logged in: user's own groups + non-hidden preset groups
      const hidden = await db
        .select()
        .from(hiddenGroups)
        .where(eq(hiddenGroups.userId, ctx.user.id));
      const hiddenGroupIds = hidden.map((h) => h.groupId);

      let groupsQuery;
      if (hiddenGroupIds.length > 0) {
        groupsQuery = db
          .select()
          .from(ruleGroups)
          .where(
            or(
              eq(ruleGroups.userId, ctx.user.id),
              and(
                isNull(ruleGroups.userId),
                notInArray(ruleGroups.id, hiddenGroupIds)
              )
            )
          );
      } else {
        groupsQuery = db
          .select()
          .from(ruleGroups)
          .where(
            or(
              isNull(ruleGroups.userId),
              eq(ruleGroups.userId, ctx.user.id)
            )
          );
      }
      const groups = await groupsQuery;
      const result = await Promise.all(
        groups.map(async (group) => {
          const ruleCount = await db
            .select()
            .from(rules)
            .where(eq(rules.groupId, group.id))
            .then((rows) => rows.length);
          return { ...group, ruleCount };
        })
      );
      return result;
    } else {
      // Not logged in: only preset groups
      const presetGroups = await db
        .select()
        .from(ruleGroups)
        .where(isNull(ruleGroups.userId));
      const result = await Promise.all(
        presetGroups.map(async (group) => {
          const ruleCount = await db
            .select()
            .from(rules)
            .where(eq(rules.groupId, group.id))
            .then((rows) => rows.length);
          return { ...group, ruleCount };
        })
      );
      return result;
    }
  }),

  listHiddenGroups: authedQuery.query(async ({ ctx }) => {
    const db = getDb();

    const hidden = await db
      .select()
      .from(hiddenGroups)
      .where(eq(hiddenGroups.userId, ctx.user.id));

    if (hidden.length === 0) return [];

    const hiddenGroupIds = hidden.map((h) => h.groupId);
    const presetGroups = await db
      .select()
      .from(ruleGroups)
      .where(inArray(ruleGroups.id, hiddenGroupIds));

    const result = await Promise.all(
      presetGroups.map(async (group) => {
        const ruleCount = await db
          .select()
          .from(rules)
          .where(eq(rules.groupId, group.id))
          .then((rows) => rows.length);
        return { ...group, ruleCount };
      })
    );

    return result;
  }),

  createGroup: authedQuery
    .input(z.object({ name: z.string().min(1).max(50) }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      
      await db.insert(ruleGroups).values({
        name: input.name,
        userId: ctx.user.id,
      });
      
      const newGroup = await db.select().from(ruleGroups)
        .where(and(eq(ruleGroups.name, input.name), eq(ruleGroups.userId, ctx.user.id)))
        .orderBy(ruleGroups.id)
        .then(rows => rows[rows.length - 1]);
      
      return { id: newGroup.id, name: input.name };
    }),

  deleteGroup: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      
      const group = await db
        .select()
        .from(ruleGroups)
        .where(eq(ruleGroups.id, input.id))
        .then((rows) => rows[0]);
      
      if (!group) {
        throw new TRPCError({ code: "NOT_FOUND", message: "分组不存在" });
      }
      
      // User's own group: truly delete
      if (group.userId) {
        if (group.userId !== ctx.user.id) {
          throw new TRPCError({ code: "FORBIDDEN", message: "无权删除此分组" });
        }
        await db.delete(rules).where(eq(rules.groupId, input.id));
        await db.delete(ruleGroups).where(eq(ruleGroups.id, input.id));
        return { success: true, deletedGroup: group.name, action: "deleted" };
      }
      
      // Preset group (userId is null)
      if (ctx.user.role === "admin") {
        // Admin truly deletes preset group
        await db.delete(rules).where(eq(rules.groupId, input.id));
        await db.delete(ruleGroups).where(eq(ruleGroups.id, input.id));
        return { success: true, deletedGroup: group.name, action: "deleted" };
      } else {
        // Non-admin: just hide the preset group for this user
        await db.insert(hiddenGroups).values({
          userId: ctx.user.id,
          groupId: input.id,
        });
        return { success: true, deletedGroup: group.name, action: "hidden" };
      }
    }),

  restoreGroup: authedQuery
    .input(z.object({ groupId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      
      await db
        .delete(hiddenGroups)
        .where(
          and(
            eq(hiddenGroups.userId, ctx.user.id),
            eq(hiddenGroups.groupId, input.groupId)
          )
        );
      
      return { success: true };
    }),

  updateGroup: authedQuery
    .input(z.object({ id: z.number(), name: z.string().min(1).max(50) }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      const group = await db
        .select()
        .from(ruleGroups)
        .where(eq(ruleGroups.id, input.id))
        .then((rows) => rows[0]);

      if (!group) {
        throw new TRPCError({ code: "NOT_FOUND", message: "分组不存在" });
      }

      // User can edit their own groups; admin can edit preset groups
      if (group.userId && group.userId !== ctx.user.id) {
        throw new TRPCError({ code: "FORBIDDEN", message: "无权编辑此分组" });
      }
      if (!group.userId && ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "只有管理员可以编辑预置分组" });
      }

      await db
        .update(ruleGroups)
        .set({ name: input.name })
        .where(eq(ruleGroups.id, input.id));

      return { success: true };
    }),

  listRules: publicQuery
    .input(
      z.object({
        groupId: z.number().optional(),
        search: z.string().optional(),
      }).optional()
    )
    .query(async ({ ctx, input }) => {
      const db = getDb();

      let query = db.select().from(rules);

      const conditions = [];

      if (input?.groupId) {
        conditions.push(eq(rules.groupId, input.groupId));
      }

      if (ctx.user) {
        // Logged in: preset rules + user's own rules
        conditions.push(
          or(
            eq(rules.isPreset, true),
            and(
              eq(rules.userId, ctx.user.id),
              ne(rules.isPreset, true)
            )
          )
        );
      } else {
        // Not logged in: only preset rules
        conditions.push(eq(rules.isPreset, true));
      }

      if (input?.search) {
        conditions.push(
          or(
            like(rules.name, `%${input.search}%`),
            like(rules.content, `%${input.search}%`)
          )
        );
      }

      if (conditions.length > 0) {
        query = query.where(and(...conditions)) as typeof query;
      }

      const ruleList = await query;

      // Get group names
      const result = await Promise.all(
        ruleList.map(async (rule) => {
          const group = await db
            .select()
            .from(ruleGroups)
            .where(eq(ruleGroups.id, rule.groupId))
            .then((rows) => rows[0]);

          return {
            ...rule,
            groupName: group?.name || "未分组",
          };
        })
      );

      return result;
    }),

  getRule: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();

      const rule = await db
        .select()
        .from(rules)
        .where(eq(rules.id, input.id))
        .then((rows) => rows[0]);

      if (!rule) {
        throw new TRPCError({ code: "NOT_FOUND", message: "规则不存在" });
      }

      // Not logged in: only preset rules visible
      if (!ctx.user && !rule.isPreset) {
        throw new TRPCError({ code: "FORBIDDEN", message: "登录后可查看" });
      }

      // Logged in: user-created rules only to creator
      if (ctx.user && !rule.isPreset && rule.userId !== ctx.user.id) {
        throw new TRPCError({ code: "FORBIDDEN", message: "无权查看此规则" });
      }

      return rule;
    }),

  createRule: authedQuery
    .input(
      z.object({
        name: z.string().min(1).max(100),
        content: z.string().min(1),
        groupId: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      // Check if target group is preset
      const targetGroup = await db
        .select()
        .from(ruleGroups)
        .where(eq(ruleGroups.id, input.groupId))
        .then((rows) => rows[0]);

      if (targetGroup && !targetGroup.userId && ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "只有管理员可以向预置分组添加规则" });
      }

      await db.insert(rules).values({
        name: input.name,
        content: input.content,
        groupId: input.groupId,
        userId: ctx.user.id,
        isPreset: false,
      });

      const newRule = await db.select().from(rules)
        .where(and(eq(rules.name, input.name), eq(rules.userId, ctx.user.id)))
        .orderBy(rules.id)
        .then(rows => rows[rows.length - 1]);

      return { id: newRule.id, ...input };
    }),

  updateRule: authedQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1).max(100).optional(),
        content: z.string().min(1).optional(),
        groupId: z.number().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      
      const rule = await db
        .select()
        .from(rules)
        .where(eq(rules.id, input.id))
        .then((rows) => rows[0]);
      
      if (!rule) {
        throw new TRPCError({ code: "NOT_FOUND", message: "规则不存在" });
      }
      
      // Preset rules: only admin can edit
      // User rules: only owner can edit
      if (rule.isPreset && ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "只有管理员可以编辑预置规则" });
      }
      if (!rule.isPreset && rule.userId !== ctx.user.id) {
        throw new TRPCError({ code: "FORBIDDEN", message: "无权修改此规则" });
      }
      
      const updateData: Record<string, unknown> = {};
      if (input.name) updateData.name = input.name;
      if (input.content) updateData.content = input.content;
      if (input.groupId) updateData.groupId = input.groupId;
      
      await db
        .update(rules)
        .set(updateData)
        .where(eq(rules.id, input.id));
      
      return { id: input.id };
    }),

  deleteRule: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      
      const rule = await db
        .select()
        .from(rules)
        .where(eq(rules.id, input.id))
        .then((rows) => rows[0]);
      
      if (!rule) {
        throw new TRPCError({ code: "NOT_FOUND", message: "规则不存在" });
      }
      
      // Can delete user's own rules or copies of preset rules
      if (rule.userId !== ctx.user.id) {
        throw new TRPCError({ code: "FORBIDDEN", message: "无权删除此规则" });
      }
      
      await db.delete(rules).where(eq(rules.id, input.id));
      
      return { success: true };
    }),

  bulkImport: authedQuery
    .input(
      z.object({
        rules: z.array(
          z.object({
            name: z.string().min(1),
            content: z.string().min(1),
          })
        ),
        groupId: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      if (input.rules.length === 0) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "规则列表为空" });
      }

      if (input.rules.length > 100) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "单次最多导入100条规则" });
      }

      // Check if target group is preset
      const targetGroup = await db
        .select()
        .from(ruleGroups)
        .where(eq(ruleGroups.id, input.groupId))
        .then((rows) => rows[0]);

      if (targetGroup && !targetGroup.userId && ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "只有管理员可以向预置分组导入规则" });
      }

      const values = input.rules.map((r) => ({
        name: r.name,
        content: r.content,
        groupId: input.groupId,
        userId: ctx.user.id,
        isPreset: false,
      }));

      await db.insert(rules).values(values);

      return { imported: input.rules.length };
    }),

  extractRules: authedQuery
    .input(
      z.object({
        roomCode: z.string(),
        groupIds: z.array(z.number()).min(1),
        count: z.number().min(1).max(20),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      
      const room = await db
        .select()
        .from(rooms)
        .where(eq(rooms.code, input.roomCode))
        .then((rows) => rows[0]);
      
      if (!room) {
        throw new TRPCError({ code: "NOT_FOUND", message: "房间不存在" });
      }
      
      const player = await db
        .select()
        .from(roomPlayers)
        .where(
          and(
            eq(roomPlayers.userId, ctx.user.id),
            eq(roomPlayers.roomCode, input.roomCode)
          )
        )
        .then((rows) => rows[0]);
      
      if (!player || (!player.isAdmin && room.hostId !== ctx.user.id)) {
        throw new TRPCError({ code: "FORBIDDEN", message: "权限不足" });
      }
      
      // Get rules from multiple groups
      const allRules = await db
        .select()
        .from(rules)
        .where(inArray(rules.groupId, input.groupIds));
      
      if (allRules.length === 0) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "选中的分组没有规则" });
      }
      
      // Get active players
      const activePlayers = await db
        .select()
        .from(roomPlayers)
        .where(
          and(
            eq(roomPlayers.roomCode, input.roomCode),
            and(ne(roomPlayers.team, "spectator"))
          )
        );
      
      if (activePlayers.length === 0) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "没有已分配队伍的玩家" });
      }
      
      // Shuffle rules and assign
      const shuffledRules = [...allRules].sort(() => Math.random() - 0.5);
      
      const results: {
        playerId: number;
        userId: number;
        ruleId: number;
        ruleName: string;
      }[] = [];
      
      for (let i = 0; i < activePlayers.length; i++) {
        const rule = shuffledRules[i % shuffledRules.length];
        const p = activePlayers[i];
        
        await db
          .update(roomPlayers)
          .set({ assignedRuleId: rule.id })
          .where(eq(roomPlayers.id, p.id));
        
        results.push({
          playerId: p.id,
          userId: p.userId,
          ruleId: rule.id,
          ruleName: rule.name,
        });
      }
      
      return results;
    }),

  copyRules: authedQuery
    .input(
      z.object({
        ruleIds: z.array(z.number()).min(1),
        targetGroupId: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      // Get all rules to copy
      const rulesToCopy = await db
        .select()
        .from(rules)
        .where(inArray(rules.id, input.ruleIds));

      if (rulesToCopy.length === 0) {
        throw new TRPCError({ code: "NOT_FOUND", message: "规则不存在" });
      }

      // Insert copies (user-created, not preset)
      const values = rulesToCopy.map((r) => ({
        name: r.name,
        content: r.content,
        groupId: input.targetGroupId,
        userId: ctx.user.id,
        isPreset: false,
      }));

      await db.insert(rules).values(values);

      return { copied: values.length };
    }),

  clearRuleAssignments: authedQuery
    .input(z.object({ roomCode: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      
      const room = await db
        .select()
        .from(rooms)
        .where(eq(rooms.code, input.roomCode))
        .then((rows) => rows[0]);
      
      if (!room) {
        throw new TRPCError({ code: "NOT_FOUND", message: "房间不存在" });
      }
      
      const player = await db
        .select()
        .from(roomPlayers)
        .where(
          and(
            eq(roomPlayers.userId, ctx.user.id),
            eq(roomPlayers.roomCode, input.roomCode)
          )
        )
        .then((rows) => rows[0]);
      
      if (!player || (!player.isAdmin && room.hostId !== ctx.user.id)) {
        throw new TRPCError({ code: "FORBIDDEN", message: "权限不足" });
      }
      
      await db
        .update(roomPlayers)
        .set({ assignedRuleId: null })
        .where(eq(roomPlayers.roomCode, input.roomCode));
      
      return { success: true };
    }),

  moveRules: authedQuery
    .input(
      z.object({
        ruleIds: z.array(z.number()).min(1),
        targetGroupId: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      // Verify target group exists and is accessible
      const targetGroup = await db
        .select()
        .from(ruleGroups)
        .where(eq(ruleGroups.id, input.targetGroupId))
        .then((rows) => rows[0]);

      if (!targetGroup) {
        throw new TRPCError({ code: "NOT_FOUND", message: "目标分组不存在" });
      }

      // Get rules to move - only user-created rules can be moved
      const rulesToMove = await db
        .select()
        .from(rules)
        .where(inArray(rules.id, input.ruleIds));

      // Filter: only move rules owned by current user
      const movable = rulesToMove.filter((r) => r.userId === ctx.user.id);
      if (movable.length === 0) {
        throw new TRPCError({ code: "FORBIDDEN", message: "没有可移动的规则（只能移动自己创建的规则）" });
      }

      const movableIds = movable.map((r) => r.id);

      await db
        .update(rules)
        .set({ groupId: input.targetGroupId })
        .where(inArray(rules.id, movableIds));

      return { moved: movableIds.length };
    }),

  bulkDeleteRules: authedQuery
    .input(z.object({ ruleIds: z.array(z.number()).min(1) }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      // Get rules to delete
      const rulesToDelete = await db
        .select()
        .from(rules)
        .where(inArray(rules.id, input.ruleIds));

      // Filter: only delete rules owned by current user
      const deletable = rulesToDelete.filter((r) => r.userId === ctx.user.id);
      if (deletable.length === 0) {
        throw new TRPCError({ code: "FORBIDDEN", message: "没有可删除的规则（只能删除自己创建的规则）" });
      }

      const deletableIds = deletable.map((r) => r.id);

      await db.delete(rules).where(inArray(rules.id, deletableIds));

      return { deleted: deletableIds.length };
    }),
});
