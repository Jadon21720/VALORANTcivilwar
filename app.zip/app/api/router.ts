import { authRouter } from "./auth-router";
import { roomRouter } from "./room-router";
import { agentRouter } from "./agent-router";
import { ruleRouter } from "./rule-router";
import { bookingRouter } from "./booking-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  room: roomRouter,
  agent: agentRouter,
  rule: ruleRouter,
  booking: bookingRouter,
});

export type AppRouter = typeof appRouter;
