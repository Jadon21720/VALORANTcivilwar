import { z } from "zod";
import { createRouter, publicQuery, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { agents, roomPlayers, rooms } from "@db/schema";
import { eq, and, ne } from "drizzle-orm";
import { TRPCError } from "@trpc/server";

export const agentRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(agents);
  }),

  extract: authedQuery
    .input(
      z.object({
        roomCode: z.string(),
        agentPerPosition: z.number().min(1).max(3).default(1),
        undercoverEnabled: z.boolean().default(false),
        undercoverPerTeam: z.number().min(0).max(2).default(1),
        roleConfig: z.object({
          defender: z.object({
            duelist: z.number().default(2),
            initiator: z.number().default(1),
            controller: z.number().default(1),
            sentinel: z.number().default(1),
          }).optional(),
          attacker: z.object({
            duelist: z.number().default(2),
            initiator: z.number().default(1),
            controller: z.number().default(1),
            sentinel: z.number().default(1),
          }).optional(),
        }).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      const room = await db
        .select()
        .from(rooms)
        .where(eq(rooms.code, input.roomCode))
        .then((rows) => rows[0]);

      if (!room) {
        throw new TRPCError({ code: "NOT_FOUND", message: "房间不存在" });
      }

      const player = await db
        .select()
        .from(roomPlayers)
        .where(
          and(
            eq(roomPlayers.userId, ctx.user.id),
            eq(roomPlayers.roomCode, input.roomCode)
          )
        )
        .then((rows) => rows[0]);

      if (!player || (!player.isAdmin && room.hostId !== ctx.user.id)) {
        throw new TRPCError({ code: "FORBIDDEN", message: "权限不足" });
      }

      const allAgents = await db.select().from(agents);

      const activePlayers = await db
        .select()
        .from(roomPlayers)
        .where(
          and(
            eq(roomPlayers.roomCode, input.roomCode),
            ne(roomPlayers.team, "spectator"),
          )
        );

      if (activePlayers.length === 0) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "没有已分配队伍的玩家" });
      }

      // Group agents by role
      const agentsByRole: Record<string, typeof allAgents> = {
        duelist: allAgents.filter((a) => a.role === "duelist"),
        controller: allAgents.filter((a) => a.role === "controller"),
        initiator: allAgents.filter((a) => a.role === "initiator"),
        sentinel: allAgents.filter((a) => a.role === "sentinel"),
      };

      // Default role config: 2 duelist, 1 initiator, 1 controller, 1 sentinel
      const defaultConfig = {
        duelist: 2, initiator: 1, controller: 1, sentinel: 1,
      };

      const defenderConfig = input.roleConfig?.defender || defaultConfig;
      const attackerConfig = input.roleConfig?.attacker || defaultConfig;

      // Build assignment pool: pick N agents from each role, ensuring no duplicates within a team
      function buildTeamAssignment(
        config: Record<string, number> | undefined,
        agentPool: Record<string, typeof allAgents>,
        teamSize: number
      ): typeof allAgents {
        const safeConfig = config || defaultConfig;
        const selected: typeof allAgents = [];
        const usedIds = new Set<number>();

        // Pick required role counts
        for (const [role, count] of Object.entries(safeConfig)) {
          const roleAgents = agentPool[role] || [];
          // Shuffle role agents
          const shuffled = [...roleAgents].sort(() => Math.random() - 0.5);
          for (let i = 0; i < Math.min(count as number, shuffled.length); i++) {
            if (!usedIds.has(shuffled[i].id)) {
              selected.push(shuffled[i]);
              usedIds.add(shuffled[i].id);
            }
          }
        }

        // If we don't have enough unique agents, fill with random unused agents
        const remainingAgents = [...allAgents]
          .filter((a) => !usedIds.has(a.id))
          .sort(() => Math.random() - 0.5);

        while (selected.length < teamSize && remainingAgents.length > 0) {
          const agent = remainingAgents.shift()!;
          selected.push(agent);
          usedIds.add(agent.id);
        }

        // Shuffle final selection
        return selected.sort(() => Math.random() - 0.5);
      }

      const defenders = activePlayers.filter((p) => p.team === "defender");
      const attackers = activePlayers.filter((p) => p.team === "attacker");

      const defenderPool = buildTeamAssignment(defenderConfig, agentsByRole, defenders.length);
      const attackerPool = buildTeamAssignment(attackerConfig, agentsByRole, attackers.length);

      const results: {
        playerId: number;
        userId: number;
        agentId: number | null;
        agentName: string | null;
        isUndercover: boolean;
      }[] = [];

      // Assign to defenders
      for (let i = 0; i < defenders.length; i++) {
        const p = defenders[i];
        const agent = defenderPool[i % defenderPool.length];

        await db
          .update(roomPlayers)
          .set({ assignedAgentId: agent.id })
          .where(eq(roomPlayers.id, p.id));

        results.push({
          playerId: p.id,
          userId: p.userId,
          agentId: agent.id,
          agentName: agent.name,
          isUndercover: false,
        });
      }

      // Assign to attackers
      for (let i = 0; i < attackers.length; i++) {
        const p = attackers[i];
        const agent = attackerPool[i % attackerPool.length];

        await db
          .update(roomPlayers)
          .set({ assignedAgentId: agent.id })
          .where(eq(roomPlayers.id, p.id));

        results.push({
          playerId: p.id,
          userId: p.userId,
          agentId: agent.id,
          agentName: agent.name,
          isUndercover: false,
        });
      }

      // Handle undercover assignment
      if (input.undercoverEnabled && input.undercoverPerTeam > 0) {
        const shuffledDefenders = [...defenders].sort(() => Math.random() - 0.5);
        const shuffledAttackers = [...attackers].sort(() => Math.random() - 0.5);

        const undercoverIds: number[] = [];

        for (let i = 0; i < Math.min(input.undercoverPerTeam, shuffledDefenders.length); i++) {
          undercoverIds.push(shuffledDefenders[i].id);
        }

        for (let i = 0; i < Math.min(input.undercoverPerTeam, shuffledAttackers.length); i++) {
          undercoverIds.push(shuffledAttackers[i].id);
        }

        for (const id of undercoverIds) {
          await db
            .update(roomPlayers)
            .set({ isUndercover: true })
            .where(eq(roomPlayers.id, id));

          const result = results.find((r) => r.playerId === id);
          if (result) {
            result.isUndercover = true;
          }
        }
      }

      return results;
    }),

  clearAssignments: authedQuery
    .input(z.object({ roomCode: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      const room = await db
        .select()
        .from(rooms)
        .where(eq(rooms.code, input.roomCode))
        .then((rows) => rows[0]);

      if (!room) {
        throw new TRPCError({ code: "NOT_FOUND", message: "房间不存在" });
      }

      const player = await db
        .select()
        .from(roomPlayers)
        .where(
          and(
            eq(roomPlayers.userId, ctx.user.id),
            eq(roomPlayers.roomCode, input.roomCode)
          )
        )
        .then((rows) => rows[0]);

      if (!player || (!player.isAdmin && room.hostId !== ctx.user.id)) {
        throw new TRPCError({ code: "FORBIDDEN", message: "权限不足" });
      }

      await db
        .update(roomPlayers)
        .set({ assignedAgentId: null, isUndercover: false })
        .where(eq(roomPlayers.roomCode, input.roomCode));

      return { success: true };
    }),
});
