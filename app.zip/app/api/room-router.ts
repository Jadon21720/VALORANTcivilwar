import { z } from "zod";
import { createRouter, publicQuery, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { rooms, roomPlayers, users, agents, rules } from "@db/schema";
import { eq, like, or, and, count } from "drizzle-orm";
import { TRPCError } from "@trpc/server";

export const roomRouter = createRouter({
  list: publicQuery
    .input(z.object({ search: z.string().optional() }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      const search = input?.search?.trim();
      
      let query = db.select().from(rooms);
      
      if (search) {
        query = query.where(
          or(
            like(rooms.name, `%${search}%`),
            like(rooms.code, `%${search}%`)
          )
        ) as typeof query;
      }
      
      const roomList = await query.orderBy(rooms.createdAt);
      
      // Get player counts for each room
      const result = await Promise.all(
        roomList.map(async (room) => {
          const players = await db
            .select()
            .from(roomPlayers)
            .where(eq(roomPlayers.roomCode, room.code));
          
          const host = await db
            .select()
            .from(users)
            .where(eq(users.id, room.hostId))
            .then((rows) => rows[0]);
          
          return {
            ...room,
            playerCount: players.length,
            hostName: host?.nickname || host?.name || "未知",
            hostAvatar: host?.avatar || host?.gameAvatar,
          };
        })
      );
      
      return result;
    }),

  create: authedQuery
    .input(
      z.object({
        code: z.string().regex(/^[A-Z]{3}\d{3}$/, "房间码格式为3个大写字母+3个数字，如ABC123").optional(),
        name: z.string().min(1).max(50).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const userId = ctx.user.id;

      // Generate random room code if not provided
      let roomCode = input.code;
      if (!roomCode) {
        const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        const generateCode = () => {
          const l = letters[Math.floor(Math.random() * 26)] + letters[Math.floor(Math.random() * 26)] + letters[Math.floor(Math.random() * 26)];
          const n = String(Math.floor(Math.random() * 1000)).padStart(3, "0");
          return l + n;
        };
        // Keep generating until unique
        for (let i = 0; i < 100; i++) {
          const candidate = generateCode();
          const exists = await db.select().from(rooms).where(eq(rooms.code, candidate)).then((rows) => rows[0]);
          if (!exists) { roomCode = candidate; break; }
        }
        if (!roomCode) {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "无法生成唯一房间码，请重试" });
        }
      }

      // Check if user already in a room
      const existingPlayer = await db
        .select()
        .from(roomPlayers)
        .where(eq(roomPlayers.userId, userId))
        .then((rows) => rows[0]);

      if (existingPlayer) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "你已加入一个房间，请先离开当前房间",
        });
      }

      // Check if room code already exists
      const existingRoom = await db
        .select()
        .from(rooms)
        .where(eq(rooms.code, roomCode))
        .then((rows) => rows[0]);

      if (existingRoom) {
        throw new TRPCError({
          code: "CONFLICT",
          message: "该房间码已被使用",
        });
      }

      // Create room
      const roomName = input.name || `房间 ${roomCode}`;
      await db.insert(rooms).values({
        code: roomCode,
        name: roomName,
        hostId: userId,
      });

      // Add host as player (spectator initially)
      await db.insert(roomPlayers).values({
        roomCode: roomCode,
        userId: userId,
        team: "spectator",
        isAdmin: false,
      });

      // Update user's current room
      await db
        .update(users)
        .set({ currentRoomCode: roomCode })
        .where(eq(users.id, userId));
      
      return { code: roomCode, name: roomName };
    }),

  getByCode: publicQuery
    .input(z.object({ code: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      
      const room = await db
        .select()
        .from(rooms)
        .where(eq(rooms.code, input.code))
        .then((rows) => rows[0]);
      
      if (!room) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "房间不存在",
        });
      }
      
      // Get all players with user info
      const players = await db
        .select()
        .from(roomPlayers)
        .where(eq(roomPlayers.roomCode, input.code));
      
      const playersWithInfo = await Promise.all(
        players.map(async (player) => {
          const user = await db
            .select()
            .from(users)
            .where(eq(users.id, player.userId))
            .then((rows) => rows[0]);
          
          let agent = null;
          if (player.assignedAgentId) {
            agent = await db
              .select()
              .from(agents)
              .where(eq(agents.id, player.assignedAgentId))
              .then((rows) => rows[0]);
          }
          
          let rule = null;
          if (player.assignedRuleId) {
            rule = await db
              .select()
              .from(rules)
              .where(eq(rules.id, player.assignedRuleId))
              .then((rows) => rows[0]);
          }
          
          return {
            ...player,
            nickname: user?.nickname || user?.name || "未知",
            avatar: user?.avatar || user?.gameAvatar,
            agent,
            rule,
          };
        })
      );
      
      const host = await db
        .select()
        .from(users)
        .where(eq(users.id, room.hostId))
        .then((rows) => rows[0]);
      
      return {
        ...room,
        hostName: host?.nickname || host?.name,
        hostAvatar: host?.avatar || host?.gameAvatar,
        players: playersWithInfo,
      };
    }),

  join: authedQuery
    .input(z.object({ code: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const userId = ctx.user.id;
      
      // Check if already in a room
      const existing = await db
        .select()
        .from(roomPlayers)
        .where(eq(roomPlayers.userId, userId))
        .then((rows) => rows[0]);
      
      if (existing) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "你已加入一个房间",
        });
      }
      
      // Check room exists
      const room = await db
        .select()
        .from(rooms)
        .where(eq(rooms.code, input.code))
        .then((rows) => rows[0]);
      
      if (!room) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "房间不存在",
        });
      }
      
      // Check room capacity
      const playerCount = await db
        .select({ count: count() })
        .from(roomPlayers)
        .where(eq(roomPlayers.roomCode, input.code))
        .then((rows) => rows[0].count);
      
      if (playerCount >= room.maxPlayers) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "房间已满",
        });
      }
      
      await db.insert(roomPlayers).values({
        roomCode: input.code,
        userId: userId,
        team: "spectator",
      });
      
      await db
        .update(users)
        .set({ currentRoomCode: input.code })
        .where(eq(users.id, userId));
      
      return { success: true };
    }),

  leave: authedQuery.mutation(async ({ ctx }) => {
    const db = getDb();
    const userId = ctx.user.id;
    
    const player = await db
      .select()
      .from(roomPlayers)
      .where(eq(roomPlayers.userId, userId))
      .then((rows) => rows[0]);
    
    if (!player) {
      throw new TRPCError({
        code: "BAD_REQUEST",
        message: "你不在任何房间中",
      });
    }
    
    const roomCode = player.roomCode;
    
    // Remove player
    await db
      .delete(roomPlayers)
      .where(eq(roomPlayers.userId, userId));
    
    // Update user
    await db
      .update(users)
      .set({ currentRoomCode: null })
      .where(eq(users.id, userId));
    
    // Check if room is empty
    const remainingPlayers = await db
      .select({ count: count() })
      .from(roomPlayers)
      .where(eq(roomPlayers.roomCode, roomCode))
      .then((rows) => rows[0].count);
    
    if (remainingPlayers === 0) {
      // Delete empty room
      await db.delete(rooms).where(eq(rooms.code, roomCode));
    } else {
      // Check if host left, transfer host
      const room = await db
        .select()
        .from(rooms)
        .where(eq(rooms.code, roomCode))
        .then((rows) => rows[0]);
      
      if (room && room.hostId === userId) {
        // Transfer to first remaining player
        const newHost = await db
          .select()
          .from(roomPlayers)
          .where(eq(roomPlayers.roomCode, roomCode))
          .limit(1)
          .then((rows) => rows[0]);
        
        if (newHost) {
          await db
            .update(rooms)
            .set({ hostId: newHost.userId })
            .where(eq(rooms.code, roomCode));
        }
      }
    }
    
    return { success: true };
  }),

  updateInfo: authedQuery
    .input(
      z.object({
        code: z.string(),
        name: z.string().min(1).max(50).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      const room = await db
        .select()
        .from(rooms)
        .where(eq(rooms.code, input.code))
        .then((rows) => rows[0]);

      if (!room) {
        throw new TRPCError({ code: "NOT_FOUND", message: "房间不存在" });
      }

      if (room.hostId !== ctx.user.id) {
        throw new TRPCError({ code: "FORBIDDEN", message: "只有房主可以修改房间信息" });
      }

      const updateData: Record<string, unknown> = {};
      if (input.name) updateData.name = input.name;

      await db
        .update(rooms)
        .set(updateData)
        .where(eq(rooms.code, input.code));

      return { success: true };
    }),

  disband: authedQuery
    .input(z.object({ code: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      
      const room = await db
        .select()
        .from(rooms)
        .where(eq(rooms.code, input.code))
        .then((rows) => rows[0]);
      
      if (!room) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "房间不存在",
        });
      }
      
      if (room.hostId !== ctx.user.id) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "只有房主可以解散房间",
        });
      }
      
      // Remove all players
      await db
        .delete(roomPlayers)
        .where(eq(roomPlayers.roomCode, input.code));
      
      // Clear users' current room
      await db
        .update(users)
        .set({ currentRoomCode: null })
        .where(eq(users.currentRoomCode, input.code));
      
      // Delete room
      await db.delete(rooms).where(eq(rooms.code, input.code));
      
      return { success: true };
    }),

  setAdmin: authedQuery
    .input(z.object({ playerId: z.number(), isAdmin: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      
      const player = await db
        .select()
        .from(roomPlayers)
        .where(eq(roomPlayers.id, input.playerId))
        .then((rows) => rows[0]);
      
      if (!player) {
        throw new TRPCError({ code: "NOT_FOUND", message: "玩家不存在" });
      }
      
      const room = await db
        .select()
        .from(rooms)
        .where(eq(rooms.code, player.roomCode))
        .then((rows) => rows[0]);
      
      if (!room || room.hostId !== ctx.user.id) {
        throw new TRPCError({ code: "FORBIDDEN", message: "只有房主可以设置管理员" });
      }
      
      await db
        .update(roomPlayers)
        .set({ isAdmin: input.isAdmin })
        .where(eq(roomPlayers.id, input.playerId));
      
      return { success: true };
    }),

  updateSettings: authedQuery
    .input(
      z.object({
        code: z.string(),
        extractAgent: z.boolean().optional(),
        agentPerPosition: z.number().min(1).max(3).optional(),
        extractRule: z.boolean().optional(),
        ruleGroupId: z.number().optional(),
        undercoverEnabled: z.boolean().optional(),
        undercoverPerTeam: z.number().min(0).max(2).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const { code, ...settings } = input;
      
      const room = await db
        .select()
        .from(rooms)
        .where(eq(rooms.code, code))
        .then((rows) => rows[0]);
      
      if (!room) {
        throw new TRPCError({ code: "NOT_FOUND", message: "房间不存在" });
      }
      
      if (room.hostId !== ctx.user.id) {
        throw new TRPCError({ code: "FORBIDDEN", message: "只有房主可以修改设置" });
      }
      
      await db
        .update(rooms)
        .set(settings)
        .where(eq(rooms.code, code));
      
      return { success: true };
    }),

  assignTeams: authedQuery
    .input(
      z.object({
        code: z.string(),
        assignments: z.array(
          z.object({
            userId: z.number(),
            team: z.enum(["defender", "attacker", "spectator"]),
            position: z.number().nullable(),
          })
        ),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      
      const room = await db
        .select()
        .from(rooms)
        .where(eq(rooms.code, input.code))
        .then((rows) => rows[0]);
      
      if (!room) {
        throw new TRPCError({ code: "NOT_FOUND", message: "房间不存在" });
      }
      
      const player = await db
        .select()
        .from(roomPlayers)
        .where(
          and(
            eq(roomPlayers.userId, ctx.user.id),
            eq(roomPlayers.roomCode, input.code)
          )
        )
        .then((rows) => rows[0]);
      
      if (!player || (!player.isAdmin && room.hostId !== ctx.user.id)) {
        throw new TRPCError({ code: "FORBIDDEN", message: "权限不足" });
      }
      
      for (const assignment of input.assignments) {
        await db
          .update(roomPlayers)
          .set({
            team: assignment.team,
            position: assignment.position,
          })
          .where(
            and(
              eq(roomPlayers.userId, assignment.userId),
              eq(roomPlayers.roomCode, input.code)
            )
          );
      }
      
      return { success: true };
    }),

  kickPlayer: authedQuery
    .input(z.object({ playerId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      
      const player = await db
        .select()
        .from(roomPlayers)
        .where(eq(roomPlayers.id, input.playerId))
        .then((rows) => rows[0]);
      
      if (!player) {
        throw new TRPCError({ code: "NOT_FOUND", message: "玩家不存在" });
      }
      
      const room = await db
        .select()
        .from(rooms)
        .where(eq(rooms.code, player.roomCode))
        .then((rows) => rows[0]);
      
      // Host or admin can kick
      const kicker = await db
        .select()
        .from(roomPlayers)
        .where(
          and(
            eq(roomPlayers.userId, ctx.user.id),
            eq(roomPlayers.roomCode, player.roomCode)
          )
        )
        .then((rows) => rows[0]);
      
      const isHostKicker = room && room.hostId === ctx.user.id;
      const isAdminKicker = kicker && kicker.isAdmin;
      
      if (!isHostKicker && !isAdminKicker) {
        throw new TRPCError({ code: "FORBIDDEN", message: "只有房主或管理员可以踢人" });
      }
      
      await db
        .delete(roomPlayers)
        .where(eq(roomPlayers.id, input.playerId));
      
      await db
        .update(users)
        .set({ currentRoomCode: null })
        .where(eq(users.id, player.userId));
      
      return { success: true };
    }),

  updateCode: authedQuery
    .input(
      z.object({
        oldCode: z.string(),
        newCode: z.string().regex(/^[A-Z]{3}\d{3}$/, "房间码格式为3个大写字母+3个数字，如ABC123"),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      const room = await db
        .select()
        .from(rooms)
        .where(eq(rooms.code, input.oldCode))
        .then((rows) => rows[0]);

      if (!room) {
        throw new TRPCError({ code: "NOT_FOUND", message: "房间不存在" });
      }

      if (room.hostId !== ctx.user.id) {
        throw new TRPCError({ code: "FORBIDDEN", message: "只有房主可以修改房间码" });
      }

      // Check if new code already exists
      const existingRoom = await db
        .select()
        .from(rooms)
        .where(eq(rooms.code, input.newCode))
        .then((rows) => rows[0]);

      if (existingRoom && existingRoom.code !== input.oldCode) {
        throw new TRPCError({ code: "CONFLICT", message: "该房间码已被使用" });
      }

      // Update room code (requires delete + insert since it's a PK)
      await db.transaction(async (tx) => {
        // Get current room data
        const roomData = { ...room };
        
        // Update all roomPlayers roomCode references
        await tx
          .update(roomPlayers)
          .set({ roomCode: input.newCode })
          .where(eq(roomPlayers.roomCode, input.oldCode));

        // Delete old room and insert with new code
        await tx.delete(rooms).where(eq(rooms.code, input.oldCode));
        await tx.insert(rooms).values({
          ...roomData,
          code: input.newCode,
        });

        // Update users currentRoomCode
        await tx
          .update(users)
          .set({ currentRoomCode: input.newCode })
          .where(eq(users.currentRoomCode, input.oldCode));
      });

      return { newCode: input.newCode };
    }),

  moveToSlot: authedQuery
    .input(
      z.object({
        code: z.string(),
        team: z.string(),
        position: z.number().nullable().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const userId = ctx.user.id;

      await db
        .update(roomPlayers)
        .set({
          team: input.team as "defender" | "attacker" | "spectator",
          position: input.position ?? null,
        })
        .where(
          and(
            eq(roomPlayers.userId, userId),
            eq(roomPlayers.roomCode, input.code)
          )
        );

      return { success: true };
    }),

  becomeSpectator: authedQuery
    .input(z.object({ code: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const userId = ctx.user.id;

      await db
        .update(roomPlayers)
        .set({ team: "spectator", position: null })
        .where(
          and(
            eq(roomPlayers.userId, userId),
            eq(roomPlayers.roomCode, input.code)
          )
        );

      return { success: true };
    }),

  requestSwap: authedQuery
    .input(
      z.object({
        code: z.string(),
        targetPlayerId: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const userId = ctx.user.id;

      const me = await db
        .select()
        .from(roomPlayers)
        .where(
          and(
            eq(roomPlayers.userId, userId),
            eq(roomPlayers.roomCode, input.code)
          )
        )
        .then((rows) => rows[0]);

      const target = await db
        .select()
        .from(roomPlayers)
        .where(eq(roomPlayers.id, input.targetPlayerId))
        .then((rows) => rows[0]);

      if (!me || !target) {
        throw new TRPCError({ code: "NOT_FOUND", message: "玩家不存在" });
      }

      // Swap team and position
      await db
        .update(roomPlayers)
        .set({ team: target.team, position: target.position })
        .where(eq(roomPlayers.id, me.id));

      await db
        .update(roomPlayers)
        .set({ team: me.team, position: me.position })
        .where(eq(roomPlayers.id, target.id));

      return { success: true };
    }),
});
