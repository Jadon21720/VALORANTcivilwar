import { Hono } from "hono";
import { bodyLimit } from "hono/body-limit";
import type { HttpBindings } from "@hono/node-server";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { appRouter } from "./router";
import { createContext } from "./context";
import { env } from "./lib/env";
import { createOAuthCallbackHandler } from "./kimi/auth";
import { Paths } from "@contracts/constants";
import { getDb } from "./queries/connection";
import { agents, ruleGroups, rules } from "@db/schema";
import { eq } from "drizzle-orm";

const app = new Hono<{ Bindings: HttpBindings }>();

app.use(bodyLimit({ maxSize: 50 * 1024 * 1024 }));
app.get(Paths.oauthCallback, createOAuthCallbackHandler());

// Seed endpoint - supports ?force=1 to reseed
app.get("/api/seed", async (c) => {
  try {
    const db = getDb();
    const force = c.req.query("force") === "1";
    
    // Check if already seeded with new format (5 groups)
    const existingGroups = await db.select().from(ruleGroups);
    const hasNewFormat = existingGroups.length >= 5;
    
    if (!force && hasNewFormat) {
      return c.json({ message: "Data already seeded with new format", groups: existingGroups.length });
    }
    
    // If old format exists (1 "推荐" group) or force, clean up and reseed
    if (existingGroups.length > 0) {
      // Delete all existing rules first
      await db.delete(rules);
      // Delete all existing groups
      await db.delete(ruleGroups);
    }
    
    // Seed agents
    const agentData = [
      { name: "炼狱", nameEn: "Brimstone", role: "controller" as const, color: "#FF8C00" },
      { name: "蝰蛇", nameEn: "Viper", role: "controller" as const, color: "#00FF00" },
      { name: "幽影", nameEn: "Omen", role: "controller" as const, color: "#4B0082" },
      { name: "零", nameEn: "Cypher", role: "sentinel" as const, color: "#1E90FF" },
      { name: "猎枭", nameEn: "Sova", role: "initiator" as const, color: "#00BFFF" },
      { name: "贤者", nameEn: "Sage", role: "sentinel" as const, color: "#00FA9A" },
      { name: "不死鸟", nameEn: "Phoenix", role: "duelist" as const, color: "#FF4500" },
      { name: "捷风", nameEn: "Jett", role: "duelist" as const, color: "#87CEEB" },
      { name: "雷兹", nameEn: "Raze", role: "duelist" as const, color: "#FFD700" },
      { name: "铁臂", nameEn: "Breach", role: "initiator" as const, color: "#D2691E" },
      { name: "芮娜", nameEn: "Reyna", role: "duelist" as const, color: "#9400D3" },
      { name: "奇乐", nameEn: "Killjoy", role: "sentinel" as const, color: "#FF69B4" },
      { name: "斯凯", nameEn: "Skye", role: "initiator" as const, color: "#32CD32" },
      { name: "夜露", nameEn: "Yoru", role: "duelist" as const, color: "#4169E1" },
      { name: "星礈", nameEn: "Astra", role: "controller" as const, color: "#9370DB" },
      { name: "KAY/O", nameEn: "KAY/O", role: "initiator" as const, color: "#B0C4DE" },
      { name: "尚勃勒", nameEn: "Chamber", role: "sentinel" as const, color: "#DAA520" },
      { name: "霓虹", nameEn: "Neon", role: "duelist" as const, color: "#00FFFF" },
      { name: "黑梦", nameEn: "Fade", role: "initiator" as const, color: "#8B008B" },
      { name: "海神", nameEn: "Harbor", role: "controller" as const, color: "#20B2AA" },
      { name: "盖可", nameEn: "Gekko", role: "initiator" as const, color: "#7CFC00" },
      { name: "钢锁", nameEn: "Deadlock", role: "sentinel" as const, color: "#C0C0C0" },
      { name: "壹决", nameEn: "Iso", role: "duelist" as const, color: "#DC143C" },
      { name: "暮蝶", nameEn: "Clove", role: "controller" as const, color: "#FF1493" },
    ];
    
    await db.insert(agents).values(agentData);

    // Seed 5 preset rule groups by type
    const groupNames = ["枪械-推荐", "技能-推荐", "移动-推荐", "战术-推荐", "惩罚-推荐"];
    for (const name of groupNames) {
      await db.insert(ruleGroups).values({ name, isDefault: true });
    }

    // Get all groups
    const allGroups = await db.select().from(ruleGroups);
    const getGroupId = (name: string) => allGroups.find((g) => g.name === name)?.id!;

    const weaponGroupId = getGroupId("枪械-推荐");
    const skillGroupId = getGroupId("技能-推荐");
    const moveGroupId = getGroupId("移动-推荐");
    const tacticGroupId = getGroupId("战术-推荐");
    const penaltyGroupId = getGroupId("惩罚-推荐");

    // Preset rules by type
    const weaponRules = [
      { name: "强制开镜", content: "全程只能开镜射击，禁止腰射", groupId: weaponGroupId },
      { name: "手枪专精", content: "只能使用手枪类武器：标配、鬼魅、短炮、狂怒、追猎、正义", groupId: weaponGroupId },
      { name: "霰弹枪专精", content: "只能使用霰弹枪类武器：雄鹿、判官", groupId: weaponGroupId },
      { name: "冲锋枪专精", content: "只能使用冲锋枪类武器：恶灵、蜂刺", groupId: weaponGroupId },
      { name: "狙击枪专精", content: "只能使用狙击枪类武器：冥驹、莽侠、飞将", groupId: weaponGroupId },
      { name: "机枪专精", content: "只能使用机枪类武器：战神", groupId: weaponGroupId },
      { name: "禁爆头", content: "只能攻击身体，禁止爆头击杀", groupId: weaponGroupId },
      { name: "禁急停", content: "禁止急停，只能边移动边射击", groupId: weaponGroupId },
      { name: "禁蹲射", content: "全程保持站立状态对枪，禁止蹲下射击", groupId: weaponGroupId },
      { name: "强制换弹", content: "每完成一次击杀必须立即换弹", groupId: weaponGroupId },
      { name: "强制单发", content: "只能单发点射，禁止按住连射", groupId: weaponGroupId },
      { name: "强制连射", content: "只能按住连射泼水，禁止单发点射", groupId: weaponGroupId },
      { name: "半甲限制", content: "本回合只能购买半甲", groupId: weaponGroupId },
      { name: "轻甲限制", content: "本回合只能购买轻甲", groupId: weaponGroupId },
      { name: "残血专精", content: "只能攻击残血敌人，满血目标禁止开枪", groupId: weaponGroupId },
      { name: "移动靶专精", content: "只能攻击移动中的敌人，静止目标禁止攻击", groupId: weaponGroupId },
      { name: "键位互换（纵向）", content: "W/S键位功能互换", groupId: weaponGroupId },
      { name: "键位互换（横向）", content: "A/D键位功能互换", groupId: weaponGroupId },
      { name: "退弹限制", content: "每局开始后退弹，弹匣仅保留10发子弹", groupId: weaponGroupId },
      { name: "静音作战", content: "关闭游戏内所有音效，仅保留队伍语音", groupId: weaponGroupId },
    ];

    const skillRules = [
      { name: "技能呐喊", content: "每次释放技能必须大声喊出技能名称", groupId: skillGroupId },
      { name: "技能清空", content: "每回合必须将所有技能全部使用完毕", groupId: skillGroupId },
      { name: "自伤技能", content: "技能只能朝自己脚下释放", groupId: skillGroupId },
      { name: "友伤技能", content: "技能只能朝队友脚下释放", groupId: skillGroupId },
      { name: "绝境技能", content: "必须等待所有队友倒地后才能释放技能", groupId: skillGroupId },
      { name: "灵敏度最大", content: "将鼠标灵敏度调至最高", groupId: skillGroupId },
      { name: "灵敏度最小", content: "将鼠标灵敏度调至最低", groupId: skillGroupId },
      { name: "三字限制", content: "全程说话仅限三个字", groupId: skillGroupId },
      { name: "禁回血", content: "禁止使用任何回血手段", groupId: skillGroupId },
      { name: "强制进点", content: "必须作为第一个进入包点的玩家", groupId: skillGroupId },
      { name: "禁偷侧身", content: "禁止偷袭背身和侧身，只能正面交火", groupId: skillGroupId },
      { name: "强制偷袭", content: "只能攻击背身和侧身，禁止正面交火", groupId: skillGroupId },
      { name: "强制喷漆", content: "发现敌人后必须先喷漆再开枪", groupId: skillGroupId },
      { name: "强制跑打", content: "全程必须边跑边射击，禁止站稳开枪", groupId: skillGroupId },
      { name: "指定特工", content: "必须使用队友指定的特工角色", groupId: skillGroupId },
    ];

    const moveRules = [
      { name: "螃蟹步", content: "全程只能左右横移，禁止直线前进", groupId: moveGroupId },
      { name: "贴墙走", content: "全程紧贴墙体移动，禁止离开墙体", groupId: moveGroupId },
      { name: "换弹转圈", content: "每次换弹必须原地旋转一圈", groupId: moveGroupId },
      { name: "击杀连跳", content: "每次完成击杀必须原地连续跳跃三次", groupId: moveGroupId },
      { name: "全程静步", content: "全程必须保持静步状态移动", groupId: moveGroupId },
      { name: "全程蹲走", content: "全程必须保持蹲姿移动", groupId: moveGroupId },
      { name: "单键移动", content: "只能直线移动，W/A/S/D同时仅能按住一个键", groupId: moveGroupId },
      { name: "遇敌先跳", content: "发现敌人后必须先原地跳跃一次才能开枪", groupId: moveGroupId },
      { name: "跟屁虫", content: "必须紧跟一名队友身后移动，寸步不离", groupId: moveGroupId },
      { name: "禁Peek", content: "禁止小身位探头侦察，禁止Peek", groupId: moveGroupId },
      { name: "多动症", content: "必须持续左右晃动，禁止静止不动", groupId: moveGroupId },
      { name: "倒走进点", content: "进入包点时必须倒退行走", groupId: moveGroupId },
      { name: "禁停步", content: "游戏开始后必须持续移动，禁止停下", groupId: moveGroupId },
      { name: "盯地行走", content: "必须全程低头盯着地面行走", groupId: moveGroupId },
      { name: "禁看地图", content: "全程禁止查看小地图", groupId: moveGroupId },
    ];

    const tacticRules = [
      { name: "保镖模式", content: "必须紧跟一名队友充当保镖，寸步不离", groupId: tacticGroupId },
      { name: "补枪专精", content: "只能协助队友补枪，禁止主动寻找敌人", groupId: tacticGroupId },
      { name: "假情报员", content: "全程必须报假信息，反向报点误导队友", groupId: tacticGroupId },
      { name: "让人头", content: "必须将击杀机会让给队友，禁止自己完成击杀", groupId: tacticGroupId },
      { name: "禁止单走", content: "必须与队友保持同一位置，禁止单独行动", groupId: tacticGroupId },
      { name: "遗孤推进", content: "队友阵亡后才能继续推进", groupId: tacticGroupId },
      { name: "全程静音", content: "全程禁止发信号、报点及任何形式的交流", groupId: tacticGroupId },
      { name: "离谱指挥", content: "必须指挥全队走最不合理/最离谱的路线", groupId: tacticGroupId },
      { name: "应声开枪", content: "队友开枪后才能开枪，禁止率先开火", groupId: tacticGroupId },
      { name: "人体盾牌", content: "必须主动为队友抵挡子弹和技能", groupId: tacticGroupId },
      { name: "反向报点", content: "报点时必须反着说（如将A大报为大A）", groupId: tacticGroupId },
      { name: "先包后战", content: "进攻方看到包必须先拆除再战斗；防守方必须先下包再战斗", groupId: tacticGroupId },
    ];

    const penaltyRules = [
      { name: "自嘲语录", content: "每次阵亡后必须说一句自嘲语录", groupId: penaltyGroupId },
      { name: "空枪惩罚", content: "发现敌人后必须先故意空枪三次才能正常射击", groupId: penaltyGroupId },
      { name: "死亡献唱", content: "阵亡后必须持续唱歌直至回合结束", groupId: penaltyGroupId },
      { name: "原地转圈", content: "每回合开始时必须原地转三圈", groupId: penaltyGroupId },
      { name: "报数射击", content: "每次开枪前必须从1数到3", groupId: penaltyGroupId },
      { name: "闭眼狙击", content: "使用狙击枪开镜时必须闭上一只眼睛", groupId: penaltyGroupId },
      { name: "跳跃换弹", content: "换弹时必须同时跳跃", groupId: penaltyGroupId },
      { name: "倒计时报点", content: "报点前必须倒数3秒", groupId: penaltyGroupId },
      { name: "胜利嘲讽", content: "每次击杀必须发送一条嘲讽语音", groupId: penaltyGroupId },
    ];

    const allRules = [...weaponRules, ...skillRules, ...moveRules, ...tacticRules, ...penaltyRules];

    await db.insert(rules).values(
      allRules.map((r) => ({ name: r.name, content: r.content, groupId: r.groupId, isPreset: true }))
    );

    return c.json({
      message: "Seed complete",
      agents: agentData.length,
      rules: allRules.length,
      groups: groupNames.length,
    });
  } catch (err: any) {
    return c.json({ error: err.message }, 500);
  }
});

// Deduplicate rules endpoint
app.get("/api/dedup", async (c) => {
  try {
    const db = getDb();
    
    const allRules = await db.select().from(rules);
    const seen = new Set<string>();
    const dupes: number[] = [];
    for (const r of allRules) {
      if (seen.has(r.name)) {
        dupes.push(r.id);
      } else {
        seen.add(r.name);
      }
    }
    
    if (dupes.length > 0) {
      for (const id of dupes) {
        await db.delete(rules).where(eq(rules.id, id));
      }
    }
    
    const allGroups = await db.select().from(ruleGroups);
    const groupSeen = new Set<string>();
    const groupDupes: number[] = [];
    for (const g of allGroups) {
      const key = `${g.name}_${g.userId ?? 'null'}`;
      if (groupSeen.has(key)) {
        groupDupes.push(g.id);
      } else {
        groupSeen.add(key);
      }
    }
    
    if (groupDupes.length > 0) {
      for (const id of groupDupes) {
        const firstRecGroup = allGroups.find(g => g.name === "推荐" && !groupDupes.includes(g.id));
        if (firstRecGroup) {
          await db.update(rules).set({ groupId: firstRecGroup.id }).where(eq(rules.groupId, id));
        }
        await db.delete(ruleGroups).where(eq(ruleGroups.id, id));
      }
    }
    
    return c.json({ 
      message: "Dedup complete", 
      deletedRules: dupes.length,
      deletedGroups: groupDupes.length,
      existingGroups: allGroups.length,
      note: "Now visit /api/seed?force=1 to reseed with new 5-group format"
    });
  } catch (err: any) {
    return c.json({ error: err.message }, 500);
  }
});

app.use("/api/trpc/*", async (c) => {
  return fetchRequestHandler({
    endpoint: "/api/trpc",
    req: c.req.raw,
    router: appRouter,
    createContext,
  });
});
app.all("/api/*", (c) => c.json({ error: "Not Found" }, 404));

export default app;

if (env.isProduction) {
  const { serve } = await import("@hono/node-server");
  const { serveStaticFiles } = await import("./lib/vite");
  serveStaticFiles(app);

  const port = parseInt(process.env.PORT || "3000");
  serve({ fetch: app.fetch, port }, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}
