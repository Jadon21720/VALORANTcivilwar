import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { bookings, users } from "@db/schema";
import { eq, and } from "drizzle-orm";
import { TRPCError } from "@trpc/server";

export const bookingRouter = createRouter({
  list: authedQuery
    .input(
      z.object({
        roomCode: z.string(),
        date: z.string(), // YYYY-MM-DD
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      
      const bookingList = await db
        .select()
        .from(bookings)
        .where(
          and(
            eq(bookings.roomCode, input.roomCode),
            eq(bookings.bookingDate, new Date(input.date))
          )
        );
      
      // Get user info for each booking
      const result = await Promise.all(
        bookingList.map(async (booking) => {
          const user = await db
            .select()
            .from(users)
            .where(eq(users.id, booking.userId))
            .then((rows) => rows[0]);
          
          return {
            ...booking,
            userNickname: user?.nickname || user?.name || "未知",
            userAvatar: user?.avatar || user?.gameAvatar,
          };
        })
      );
      
      return result;
    }),

  getSlotDetail: authedQuery
    .input(
      z.object({
        roomCode: z.string(),
        date: z.string(),
        timeSlot: z.string(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      
      const slotBookings = await db
        .select()
        .from(bookings)
        .where(
          and(
            eq(bookings.roomCode, input.roomCode),
            eq(bookings.bookingDate, new Date(input.date)),
            eq(bookings.timeSlot, input.timeSlot)
          )
        );
      
      const usersList = await Promise.all(
        slotBookings.map(async (b) => {
          const user = await db
            .select()
            .from(users)
            .where(eq(users.id, b.userId))
            .then((rows) => rows[0]);
          
          return {
            id: user?.id,
            nickname: user?.nickname || user?.name || "未知",
            avatar: user?.avatar || user?.gameAvatar,
          };
        })
      );
      
      return { users: usersList.filter((u) => u.id) };
    }),

  book: authedQuery
    .input(
      z.object({
        roomCode: z.string(),
        date: z.string(),
        timeSlot: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      
      try {
        await db.insert(bookings).values({
          roomCode: input.roomCode,
          userId: ctx.user.id,
          timeSlot: input.timeSlot,
          bookingDate: new Date(input.date),
        });
        
        return { success: true };
      } catch {
        throw new TRPCError({
          code: "CONFLICT",
          message: "你已预约该时间段",
        });
      }
    }),

  cancel: authedQuery
    .input(z.object({ bookingId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      
      const booking = await db
        .select()
        .from(bookings)
        .where(eq(bookings.id, input.bookingId))
        .then((rows) => rows[0]);
      
      if (!booking) {
        throw new TRPCError({ code: "NOT_FOUND", message: "预约不存在" });
      }
      
      if (booking.userId !== ctx.user.id) {
        throw new TRPCError({ code: "FORBIDDEN", message: "无权取消此预约" });
      }
      
      await db.delete(bookings).where(eq(bookings.id, input.bookingId));
      
      return { success: true };
    }),

  myBookings: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    
    return db
      .select()
      .from(bookings)
      .where(eq(bookings.userId, ctx.user.id));
  }),
});
