import * as cookie from "cookie";
import { Session } from "@contracts/constants";
import { getSessionCookieOptions } from "./lib/cookies";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { users } from "@db/schema";
import { eq } from "drizzle-orm";
import { z } from "zod";

export const authRouter = createRouter({
  me: authedQuery.query((opts) => opts.ctx.user),
  
  updateProfile: authedQuery
    .input(
      z.object({
        nickname: z.string().min(1).max(16).optional(),
        gameAvatar: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      
      const updateData: Record<string, unknown> = {};
      if (input.nickname) updateData.nickname = input.nickname;
      if (input.gameAvatar) updateData.gameAvatar = input.gameAvatar;
      
      await db
        .update(users)
        .set(updateData)
        .where(eq(users.id, ctx.user.id));
      
      return { success: true };
    }),

  logout: authedQuery.mutation(async ({ ctx }) => {
    const opts = getSessionCookieOptions(ctx.req.headers);
    ctx.resHeaders.append(
      "set-cookie",
      cookie.serialize(Session.cookieName, "", {
        httpOnly: opts.httpOnly,
        path: opts.path,
        sameSite: opts.sameSite?.toLowerCase() as "lax" | "none",
        secure: opts.secure,
        maxAge: 0,
      }),
    );
    return { success: true };
  }),
});
