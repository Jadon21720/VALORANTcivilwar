import { Routes, Route } from 'react-router'
import Home from './pages/Home'
import RoomDetail from './pages/RoomDetail'
import Rules from './pages/Rules'
import Settings from './pages/Settings'
import Guide from './pages/Guide'
import Login from "./pages/Login"
import NotFound from "./pages/NotFound"
import Navbar from "./components/Navbar"

export default function App() {
  return (
    <div className="min-h-screen bg-[#0F0F0F]">
      <Navbar />
      <main className="pt-14">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/room/:code" element={<RoomDetail />} />
          <Route path="/rules" element={<Rules />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/guide" element={<Guide />} />
          <Route path="/login" element={<Login />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
    </div>
  )
}
