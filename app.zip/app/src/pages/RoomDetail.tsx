import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft, LogOut, Trash2, Shuffle, X, ChevronDown, ChevronUp,
  Clock, UserPlus, Shield, ArrowRightLeft, EyeOff,
  Calendar, Pencil, Crown, Star, Users, MoreHorizontal,
  UserX, UserCheck, Check
} from "lucide-react";

const TIME_SLOTS = [
  "00:00-02:00", "02:00-04:00", "04:00-06:00", "06:00-08:00",
  "08:00-10:00", "10:00-12:00", "12:00-14:00", "14:00-16:00",
  "16:00-18:00", "18:00-20:00", "20:00-22:00", "22:00-24:00",
];

const ROLE_LABELS: Record<string, string> = {
  duelist: "决斗", controller: "控场", initiator: "先锋", sentinel: "哨卫",
};

const ROLE_COLORS: Record<string, string> = {
  duelist: "#FF4655", controller: "#3B82F6", initiator: "#22C55E", sentinel: "#D4AF37",
};

export default function RoomDetail() {
  const { code } = useParams<{ code: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const utils = trpc.useUtils();

  const [showExtract, setShowExtract] = useState(false);
  const [showBooking, setShowBooking] = useState(false);
  const [showBookingDetail, setShowBookingDetail] = useState<string | null>(null);
  const [bookingDate, setBookingDate] = useState(() => new Date().toISOString().split("T")[0]);
  const [swapTarget, setSwapTarget] = useState<any>(null);
  const [showLeaveConfirm, setShowLeaveConfirm] = useState(false);
  const [showHostSelect, setShowHostSelect] = useState(false);
  const [showEditRoom, setShowEditRoom] = useState(false);
  const [editRoomName, setEditRoomName] = useState("");
  const [editRoomCode, setEditRoomCode] = useState("");
  const [editRoomError, setEditRoomError] = useState("");
  const [optionPlayer, setOptionPlayer] = useState<any>(null);

  const [extractConfig, setExtractConfig] = useState({
    extractAgent: true,
    extractRule: true,
    ruleGroupIds: [] as number[],
    undercoverEnabled: false,
    undercoverPerTeam: 1,
    defenderDuelist: 2, defenderInitiator: 1, defenderController: 1, defenderSentinel: 1,
    attackerDuelist: 2, attackerInitiator: 1, attackerController: 1, attackerSentinel: 1,
  });
  const [isExtracting, setIsExtracting] = useState(false);

  const { data: room, isLoading } = trpc.room.getByCode.useQuery(
    { code: code! }, { enabled: !!code, refetchInterval: 3000 }
  );
  const { data: ruleGroups } = trpc.rule.listGroups.useQuery(undefined, { enabled: showExtract });
  // Auto-sync ruleGroupIds when ruleGroups load
  useEffect(() => {
    if (showExtract && ruleGroups && ruleGroups.length > 0) {
      setExtractConfig((c) => {
        const validIds = c.ruleGroupIds.filter((id) => ruleGroups.find((g: any) => g.id === id));
        if (validIds.length === 0) {
          return { ...c, ruleGroupIds: [ruleGroups[0].id] };
        }
        return { ...c, ruleGroupIds: validIds };
      });
    }
  }, [showExtract, ruleGroups]);
  const { data: bookings, refetch: refetchBookings } = trpc.booking.list.useQuery(
    { roomCode: code!, date: bookingDate }, { enabled: showBooking }
  );
  const { data: bookingDetail } = trpc.booking.getSlotDetail.useQuery(
    { roomCode: code!, date: bookingDate, timeSlot: showBookingDetail! },
    { enabled: !!showBookingDetail }
  );

  const leaveRoom = trpc.room.leave.useMutation({
    onSuccess: () => { utils.room.getByCode.invalidate(); utils.room.list.invalidate(); utils.auth.me.invalidate(); navigate("/"); },
  });
  const disbandRoom = trpc.room.disband.useMutation({
    onSuccess: () => { utils.room.list.invalidate(); utils.auth.me.invalidate(); navigate("/"); },
  });
  const updateInfo = trpc.room.updateInfo.useMutation({
    onSuccess: () => { utils.room.getByCode.invalidate(); },
  });
  const updateCode = trpc.room.updateCode.useMutation({
    onSuccess: () => { utils.room.getByCode.invalidate(); },
  });
  const setAdmin = trpc.room.setAdmin.useMutation({ onSuccess: () => utils.room.getByCode.invalidate() });
  const assignTeams = trpc.room.assignTeams.useMutation({ onSuccess: () => utils.room.getByCode.invalidate() });
  const moveToSlot = trpc.room.moveToSlot.useMutation({ onSuccess: () => utils.room.getByCode.invalidate() });
  const becomeSpectator = trpc.room.becomeSpectator.useMutation({ onSuccess: () => utils.room.getByCode.invalidate() });
  const kickPlayer = trpc.room.kickPlayer.useMutation({ onSuccess: () => utils.room.getByCode.invalidate() });
  const requestSwap = trpc.room.requestSwap.useMutation({
    onSuccess: () => { setSwapTarget(null); utils.room.getByCode.invalidate(); },
  });
  const extractAgents = trpc.agent.extract.useMutation({ onSuccess: () => utils.room.getByCode.invalidate() });
  const extractRules = trpc.rule.extractRules.useMutation({ onSuccess: () => utils.room.getByCode.invalidate() });
  const bookSlot = trpc.booking.book.useMutation({ onSuccess: () => refetchBookings() });
  const cancelBooking = trpc.booking.cancel.useMutation({ onSuccess: () => refetchBookings() });

  const isHost = room?.hostId === user?.id;
  const currentPlayer = room?.players.find((p: any) => p.userId === user?.id);
  const isAdmin = currentPlayer?.isAdmin || isHost;

  const defenders = room?.players.filter((p: any) => p.team === "defender") || [];
  const attackers = room?.players.filter((p: any) => p.team === "attacker") || [];
  const spectators = room?.players.filter((p: any) => p.team === "spectator") || [];

  const handleAutoAssign = () => {
    if (!room || !code) return;

    const active = room.players.filter((p: any) => p.team !== "spectator");
    const spectators = room.players.filter((p: any) => p.team === "spectator");

    const msg = `随机分配队伍\n\n${active.length} 名已分配队伍的玩家将随机打乱重新分配\n${spectators.length} 名观众席玩家保持不变\n\n确定分配？`;
    if (!confirm(msg)) return;

    // Only shuffle non-spectator players, keep spectators untouched
    const shuffled = [...active].sort(() => Math.random() - 0.5);
    const assignments: any[] = [];
    for (let i = 0; i < shuffled.length && i < 10; i++) {
      assignments.push({
        userId: shuffled[i].userId,
        team: i < 5 ? "defender" : "attacker",
        position: (i % 5) + 1,
      });
    }
    // Keep spectators as-is
    for (const s of spectators) {
      assignments.push({ userId: s.userId, team: "spectator", position: null });
    }
    assignTeams.mutate({ code, assignments });
  };

  const handleSlotClick = (team: string, position: number, existingPlayer?: any) => {
    if (!code || !currentPlayer) return;
    if (existingPlayer && existingPlayer.userId !== user?.id) {
      setSwapTarget({ ...existingPlayer, targetTeam: team, targetPosition: position });
      return;
    }
    if (existingPlayer && existingPlayer.userId === user?.id) return;
    moveToSlot.mutate({ code, team: team as any, position });
  };

  const handleSpectatorClick = () => { if (code) becomeSpectator.mutate({ code }); };

  const handleExtract = async () => {
    if (!code) return;
    setIsExtracting(true);
    try {
      if (extractConfig.extractAgent) {
        await extractAgents.mutateAsync({
          roomCode: code, agentPerPosition: 1,
          undercoverEnabled: extractConfig.undercoverEnabled,
          undercoverPerTeam: extractConfig.undercoverPerTeam,
          roleConfig: {
            defender: { duelist: extractConfig.defenderDuelist, initiator: extractConfig.defenderInitiator, controller: extractConfig.defenderController, sentinel: extractConfig.defenderSentinel },
            attacker: { duelist: extractConfig.attackerDuelist, initiator: extractConfig.attackerInitiator, controller: extractConfig.attackerController, sentinel: extractConfig.attackerSentinel },
          } as any,
        });
      }
      if (extractConfig.extractRule && extractConfig.ruleGroupIds.length > 0) {
        const activeCount = room?.players.filter((p: any) => p.team !== "spectator").length || 0;
        await extractRules.mutateAsync({ roomCode: code, groupIds: extractConfig.ruleGroupIds, count: Math.max(activeCount, 1) });
      }
    } finally {
      setTimeout(() => { setIsExtracting(false); setShowExtract(false); }, 1500);
    }
  };

  const handleBook = (slot: string) => { if (code) bookSlot.mutate({ roomCode: code, date: bookingDate, timeSlot: slot }); };
  const handleCancelBook = (bookingId: number) => { cancelBooking.mutate({ bookingId }); };
  const getSlotCount = (slot: string) => bookings?.filter((b: any) => b.timeSlot === slot).length || 0;
  const getMyBookingId = (slot: string) => bookings?.find((b: any) => b.timeSlot === slot && b.userId === user?.id)?.id;
  const isSlotBookedByMe = (slot: string) => !!getMyBookingId(slot);
  const updateField = (field: string, value: any) => setExtractConfig((c) => ({ ...c, [field]: value }));

  const handleLeave = () => {
    if (isHost) setShowLeaveConfirm(true);
    else leaveRoom.mutate();
  };

  const handleDisband = () => { if (code) disbandRoom.mutate({ code }); };
  const handleTransferHost = (newHostUserId: number) => {
    if (!code || !room) return;
    const targetPlayer = room.players.find((p: any) => p.userId === newHostUserId);
    if (!targetPlayer) return;
    setAdmin.mutate({ playerId: targetPlayer.id, isAdmin: false });
    setShowHostSelect(false);
    setShowLeaveConfirm(false);
    leaveRoom.mutate();
  };

  if (isLoading) return <div className="max-w-7xl mx-auto px-3 py-6"><div className="h-48 bg-[#1A1A1A] rounded-lg animate-pulse" /></div>;
  if (!room) return <div className="max-w-7xl mx-auto px-3 py-20 text-center"><p className="text-[#A0A0A0] mb-4">房间不存在或已解散</p><button onClick={() => navigate("/")} className="px-4 py-2 bg-[#FF4655] text-white rounded text-sm hover:bg-[#E63E4C]">返回大厅</button></div>;

  return (
    <div className="max-w-7xl mx-auto px-3 py-3">
      {/* Top Bar */}
      <div className="flex items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-2 min-w-0">
          <button onClick={() => navigate("/")} className="p-1.5 rounded hover:bg-[#232323] flex-shrink-0">
            <ArrowLeft className="w-4 h-4 text-[#A0A0A0]" />
          </button>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <h1 className="text-white text-base font-bold truncate">{room.name}</h1>
              {isHost && (
                <button onClick={() => { setEditRoomName(room.name); setEditRoomCode(room.code); setEditRoomError(""); setShowEditRoom(true); }}
                  className="p-0.5 rounded hover:bg-[#232323] text-[#A0A0A0]" title="编辑房间信息">
                  <Pencil className="w-3 h-3" />
                </button>
              )}
            </div>
            <span className="text-[#D4AF37] text-xs font-mono">{room.code}</span>
          </div>
        </div>
        <div className="flex items-center gap-1.5 flex-shrink-0">
          {isAdmin && (
            <button onClick={handleAutoAssign} className="flex items-center gap-1 px-2 py-1 bg-[#232323] border border-[#3A3A3A] text-white text-xs rounded hover:bg-[#2E2E2E]">
              <UserPlus className="w-3 h-3" />分配
            </button>
          )}
          {isAdmin && (
            <button onClick={() => setShowExtract(true)} className="flex items-center gap-1 px-2 py-1 bg-[#FF4655] text-white text-xs font-medium rounded hover:bg-[#E63E4C]">
              <Shuffle className="w-3 h-3" />抽取
            </button>
          )}
          <button onClick={handleLeave} className="flex items-center gap-1 px-2 py-1 bg-[#232323] border border-[#3A3A3A] text-[#FF4655] text-xs rounded hover:bg-[#FF4655]/10">
            <LogOut className="w-3 h-3" />{isHost ? "离开" : "离开"}
          </button>
        </div>
      </div>

      {/* Match Panel */}
      <div className="bg-[#1A1A1A] border border-[#3A3A3A] rounded-lg p-2.5 mb-2">
        {/* Desktop: left 5 vs right 5 (horizontal) */}
        <div className="hidden md:flex items-stretch gap-2">
          <div className="flex-1 min-w-0 space-y-1">
            <h3 className="text-xs font-semibold text-[#3B82F6] flex items-center gap-1 mb-1"><Shield className="w-3 h-3" />防守方</h3>
            {[1,2,3,4,5].map((pos) => {
              const p = defenders.find((d: any) => d.position === pos);
              return <CompactSlot key={`d${pos}`} player={p} position={pos} onClick={() => handleSlotClick("defender", pos, p)} onOption={() => setOptionPlayer(p)} currentUserId={user?.id} isExtracting={isExtracting} hostId={room?.hostId} />;
            })}
          </div>
          <div className="flex items-center justify-center w-8 flex-shrink-0">
            <span className="text-lg font-extrabold text-[#FF4655]" style={{ textShadow: "0 0 12px rgba(255,70,85,0.5)" }}>VS</span>
          </div>
          <div className="flex-1 min-w-0 space-y-1">
            <h3 className="text-xs font-semibold text-[#F59E0B] flex items-center gap-1 mb-1"><Shield className="w-3 h-3" />进攻方</h3>
            {[1,2,3,4,5].map((pos) => {
              const p = attackers.find((a: any) => a.position === pos);
              return <CompactSlot key={`a${pos}`} player={p} position={pos} onClick={() => handleSlotClick("attacker", pos, p)} onOption={() => setOptionPlayer(p)} currentUserId={user?.id} isExtracting={isExtracting} hostId={room?.hostId} />;
            })}
          </div>
        </div>

        {/* Mobile: top 5 vs bottom 5 (vertical) */}
        <div className="md:hidden">
          <div className="space-y-1">
            <h3 className="text-xs font-semibold text-[#3B82F6] flex items-center gap-1 mb-1"><Shield className="w-3 h-3" />防守方</h3>
            {[1,2,3,4,5].map((pos) => {
              const p = defenders.find((d: any) => d.position === pos);
              return <CompactSlot key={`md${pos}`} player={p} position={pos} onClick={() => handleSlotClick("defender", pos, p)} onOption={() => setOptionPlayer(p)} currentUserId={user?.id} isExtracting={isExtracting} hostId={room?.hostId} />;
            })}
          </div>
          <div className="flex justify-center py-1.5 my-1">
            <span className="text-base font-extrabold text-[#FF4655]" style={{ textShadow: "0 0 12px rgba(255,70,85,0.5)" }}>VS</span>
          </div>
          <div className="space-y-1">
            <h3 className="text-xs font-semibold text-[#F59E0B] flex items-center gap-1 mb-1"><Shield className="w-3 h-3" />进攻方</h3>
            {[1,2,3,4,5].map((pos) => {
              const p = attackers.find((a: any) => a.position === pos);
              return <CompactSlot key={`ma${pos}`} player={p} position={pos} onClick={() => handleSlotClick("attacker", pos, p)} onOption={() => setOptionPlayer(p)} currentUserId={user?.id} isExtracting={isExtracting} hostId={room?.hostId} />;
            })}
          </div>
        </div>
      </div>

      {/* Spectators */}
      <div className="bg-[#1A1A1A] border border-[#3A3A3A] rounded-lg p-2 mb-2">
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs text-[#A0A0A0] flex items-center gap-1"><Users className="w-3 h-3" />观众席 ({spectators.length})</span>
          {currentPlayer && currentPlayer.team !== "spectator" && (
            <button onClick={handleSpectatorClick} className="text-[10px] text-[#FF4655] hover:underline flex items-center gap-0.5">
              <ArrowRightLeft className="w-2.5 h-2.5" />切观众
            </button>
          )}
        </div>
        <div onClick={handleSpectatorClick} className={`flex flex-wrap gap-1 p-1.5 rounded border border-dashed cursor-pointer min-h-[32px] transition-all ${currentPlayer?.team === "spectator" ? "border-[#22C55E] bg-[#22C55E]/5" : "border-[#3A3A3A] active:border-[#FF4655]"}`}>
          {spectators.length > 0 ? spectators.map((s: any) => (
            <div key={s.id} className="flex items-center gap-1 bg-[#232323] rounded-full px-2 py-0.5">
              <img src={s.avatar || "/avatars/default-1.jpg"} alt="" className="w-4 h-4 rounded-full object-cover" onError={(e) => { (e.target as HTMLImageElement).src = "/avatars/default-1.jpg"; }} />
              <span className="text-[10px] text-white">{s.nickname}</span>
              {s.userId === room.hostId && <Crown className="w-2.5 h-2.5 text-[#D4AF37]" />}
              {s.isAdmin && <Star className="w-2.5 h-2.5 text-[#D4AF37] fill-[#D4AF37]" />}
            </div>
          )) : <span className="text-[10px] text-[#666666] w-full text-center">{currentPlayer?.team === "spectator" ? "你在此" : "点击加入"}</span>}
        </div>
      </div>

      {/* Booking */}
      <div className="bg-[#1A1A1A] border border-[#3A3A3A] rounded-lg p-2">
        <button onClick={() => setShowBooking(!showBooking)} className="w-full flex items-center justify-between">
          <span className="text-xs text-white font-medium flex items-center gap-1"><Clock className="w-3 h-3 text-[#3B82F6]" />预约</span>
          {showBooking ? <ChevronUp className="w-3.5 h-3.5 text-[#A0A0A0]" /> : <ChevronDown className="w-3.5 h-3.5 text-[#A0A0A0]" />}
        </button>
        <AnimatePresence>
          {showBooking && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.15 }} className="overflow-hidden">
              <div className="flex items-center gap-2 mt-2 mb-1.5">
                <Calendar className="w-3 h-3 text-[#A0A0A0]" />
                <input type="date" value={bookingDate} onChange={(e) => setBookingDate(e.target.value)} className="px-2 py-1 bg-[#232323] border border-[#3A3A3A] rounded text-white text-xs focus:border-[#FF4655] focus:outline-none" />
              </div>
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-1">
                {TIME_SLOTS.map((slot) => {
                  const count = getSlotCount(slot);
                  const bookedByMe = isSlotBookedByMe(slot);
                  const myId = getMyBookingId(slot);
                  return (
                    <button key={slot} onClick={() => bookedByMe && myId ? handleCancelBook(myId) : handleBook(slot)} onContextMenu={(e) => { e.preventDefault(); setShowBookingDetail(slot); }}
                      className={`p-1.5 rounded border text-center transition-all ${bookedByMe ? "bg-[#22C55E]/10 border-[#22C55E]" : "bg-[#232323] border-[#3A3A3A] active:border-[#FF4655]"}`}>
                      <p className="text-white text-[10px] font-medium">{slot}</p>
                      <p className={`text-[10px] ${bookedByMe ? "text-[#22C55E]" : "text-[#A0A0A0]"}`}>{count}人</p>
                      {bookedByMe && <p className="text-[9px] text-[#22C55E]">已预约</p>}
                    </button>
                  );
                })}
              </div>
              <p className="text-[#666666] text-[9px] mt-1">点击预约/取消，右键查看详情</p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Swap Modal */}
      {swapTarget && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm">
          <div className="bg-[#1A1A1A] border border-[#3A3A3A] rounded-t-xl sm:rounded-xl p-5 w-full max-w-xs sm:mx-4 animate-slide-up">
            <h2 className="text-white text-base font-bold mb-3 text-center">申请换位置</h2>
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="text-center">
                <img src={currentPlayer?.avatar || "/avatars/default-1.jpg"} alt="" className="w-10 h-10 rounded-full mx-auto mb-1 border border-[#3A3A3A] object-cover" onError={(e) => { (e.target as HTMLImageElement).src = "/avatars/default-1.jpg"; }} />
                <p className="text-white text-xs">{currentPlayer?.nickname}</p>
              </div>
              <ArrowRightLeft className="w-5 h-5 text-[#FF4655]" />
              <div className="text-center">
                <img src={swapTarget.avatar || "/avatars/default-1.jpg"} alt="" className="w-10 h-10 rounded-full mx-auto mb-1 border border-[#FF4655] object-cover" onError={(e) => { (e.target as HTMLImageElement).src = "/avatars/default-1.jpg"; }} />
                <p className="text-white text-xs">{swapTarget.nickname}</p>
              </div>
            </div>
            <button onClick={() => requestSwap.mutate({ code: code!, targetPlayerId: swapTarget.id })} className="w-full py-2 bg-[#FF4655] text-white text-sm font-semibold rounded-md hover:bg-[#E63E4C]">确认交换</button>
            <button onClick={() => setSwapTarget(null)} className="w-full py-2 mt-1.5 text-[#A0A0A0] text-xs hover:text-white">取消</button>
          </div>
        </div>
      )}

      {/* Leave Confirm Modal */}
      {showLeaveConfirm && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm">
          <div className="bg-[#1A1A1A] border border-[#3A3A3A] rounded-t-xl sm:rounded-xl p-5 w-full max-w-xs sm:mx-4 animate-slide-up">
            <h2 className="text-white text-base font-bold mb-3 text-center">你是房主，离开前请选择</h2>
            <button onClick={handleDisband} className="w-full py-2.5 bg-[#FF4655]/10 border border-[#FF4655] text-[#FF4655] text-sm font-medium rounded-md hover:bg-[#FF4655]/20 mb-2">
              <Trash2 className="w-4 h-4 inline mr-1" />解散房间
            </button>
            <button onClick={() => setShowHostSelect(true)} className="w-full py-2.5 bg-[#232323] border border-[#3A3A3A] text-white text-sm rounded-md hover:bg-[#2E2E2E] mb-2">
              <Crown className="w-4 h-4 inline mr-1" />指定新房主
            </button>
            <button onClick={() => setShowLeaveConfirm(false)} className="w-full py-2 text-[#A0A0A0] text-xs hover:text-white">取消</button>
          </div>
        </div>
      )}

      {/* Host Select Modal */}
      {showHostSelect && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm">
          <div className="bg-[#1A1A1A] border border-[#3A3A3A] rounded-t-xl sm:rounded-xl p-5 w-full max-w-xs sm:mx-4 animate-slide-up">
            <h2 className="text-white text-base font-bold mb-3">选择新房主</h2>
            <div className="space-y-1.5 max-h-60 overflow-y-auto">
              {room.players.filter((p: any) => p.userId !== user?.id).map((p: any) => (
                <button key={p.id} onClick={() => handleTransferHost(p.userId)}
                  className="w-full flex items-center gap-2 p-2 rounded-md bg-[#232323] hover:bg-[#2E2E2E] transition-colors text-left">
                  <img src={p.avatar || "/avatars/default-1.jpg"} alt="" className="w-7 h-7 rounded-full object-cover" onError={(e) => { (e.target as HTMLImageElement).src = "/avatars/default-1.jpg"; }} />
                  <span className="text-white text-sm">{p.nickname}</span>
                </button>
              ))}
            </div>
            <button onClick={() => setShowHostSelect(false)} className="w-full py-2 mt-2 text-[#A0A0A0] text-xs hover:text-white">取消</button>
          </div>
        </div>
      )}

      {/* Edit Room Info Modal */}
      {showEditRoom && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm">
          <div className="bg-[#1A1A1A] border border-[#3A3A3A] rounded-t-xl sm:rounded-xl p-5 w-full max-w-sm sm:mx-4 animate-slide-up">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-white text-lg font-bold">编辑房间信息</h2>
              <button onClick={() => setShowEditRoom(false)} className="p-1 rounded hover:bg-[#232323]"><X className="w-4 h-4 text-[#A0A0A0]" /></button>
            </div>
            <div className="space-y-3">
              {editRoomError && (
                <div className="px-3 py-2 bg-[#FF4655]/10 border border-[#FF4655]/30 rounded-md text-[#FF4655] text-sm">
                  {editRoomError}
                </div>
              )}
              <div>
                <label className="block text-xs text-[#A0A0A0] mb-1">房间名称</label>
                <input type="text" value={editRoomName} onChange={(e) => setEditRoomName(e.target.value)}
                  className="w-full px-3 py-2 bg-[#232323] border border-[#3A3A3A] rounded-md text-white text-sm focus:border-[#FF4655] focus:outline-none"
                  placeholder="房间名称" maxLength={50} />
              </div>
              <div>
                <label className="block text-xs text-[#A0A0A0] mb-1">房间码</label>
                <input type="text" value={editRoomCode}
                  onChange={(e) => setEditRoomCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6))}
                  className="w-full px-3 py-2 bg-[#232323] border border-[#3A3A3A] rounded-md text-[#D4AF37] text-sm font-mono tracking-wider focus:border-[#FF4655] focus:outline-none"
                  placeholder="ABC123" maxLength={6} />
                <p className="text-[#666666] text-[10px] mt-1">格式：3个大写字母 + 3个数字</p>
              </div>
              <button
                onClick={() => {
                  setEditRoomError("");
                  if (!editRoomName.trim()) { setEditRoomError("房间名称不能为空"); return; }
                  if (!/^[A-Z]{3}\d{3}$/.test(editRoomCode)) { setEditRoomError("房间码格式为3个大写字母+3个数字，如ABC123"); return; }
                  if (editRoomCode !== room.code) {
                    updateCode.mutate(
                      { oldCode: room.code, newCode: editRoomCode },
                      {
                        onSuccess: (data) => {
                          if (editRoomName.trim() !== room.name) {
                            updateInfo.mutate({ code: data.newCode, name: editRoomName.trim() });
                          }
                          setShowEditRoom(false);
                          navigate(`/room/${data.newCode}`, { replace: true });
                        },
                        onError: (err) => setEditRoomError(err.message),
                      }
                    );
                  } else {
                    updateInfo.mutate(
                      { code: room.code, name: editRoomName.trim() },
                      { onSuccess: () => setShowEditRoom(false), onError: (err) => setEditRoomError(err.message) }
                    );
                  }
                }}
                className="w-full py-2.5 bg-[#FF4655] text-white text-sm font-semibold rounded-md hover:bg-[#E63E4C] transition-colors"
              >
                保存
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Extract Modal */}
      {showExtract && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm">
          <div className="bg-[#1A1A1A] border border-[#3A3A3A] rounded-t-xl sm:rounded-xl p-5 w-full max-w-md sm:mx-4 animate-slide-up max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-white text-lg font-bold">抽取设置</h2>
              <button onClick={() => setShowExtract(false)} className="p-1 rounded hover:bg-[#232323]"><X className="w-4 h-4 text-[#A0A0A0]" /></button>
            </div>
            <div className="space-y-3">
              <ToggleRow label="抽取角色" value={extractConfig.extractAgent} onChange={(v) => updateField("extractAgent", v)} />
              {extractConfig.extractAgent && (
                <div className="pl-3 space-y-2 border-l-2 border-[#FF4655]/20">
                  <p className="text-xs text-[#A0A0A0]">角色类型数量</p>
                  <div className="grid grid-cols-2 gap-x-3 gap-y-1.5 text-xs">
                    <div className="text-[#3B82F6] font-medium text-[10px]">防守方</div>
                    <div className="text-[#F59E0B] font-medium text-[10px]">进攻方</div>
                    {["duelist", "initiator", "controller", "sentinel"].map((role) => (
                      <div key={role} className="contents">
                        <div className="flex items-center gap-1">
                          <span className="text-[10px] w-8" style={{ color: ROLE_COLORS[role] }}>{ROLE_LABELS[role]}</span>
                          <input type="number" min={0} max={5} value={extractConfig[`defender${role.charAt(0).toUpperCase() + role.slice(1)}` as keyof typeof extractConfig] as number}
                            onChange={(e) => updateField(`defender${role.charAt(0).toUpperCase() + role.slice(1)}`, Number(e.target.value))}
                            className="w-10 px-1 py-0.5 bg-[#232323] border border-[#3A3A3A] rounded text-white text-center text-xs" />
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="text-[10px] w-8" style={{ color: ROLE_COLORS[role] }}>{ROLE_LABELS[role]}</span>
                          <input type="number" min={0} max={5} value={extractConfig[`attacker${role.charAt(0).toUpperCase() + role.slice(1)}` as keyof typeof extractConfig] as number}
                            onChange={(e) => updateField(`attacker${role.charAt(0).toUpperCase() + role.slice(1)}`, Number(e.target.value))}
                            className="w-10 px-1 py-0.5 bg-[#232323] border border-[#3A3A3A] rounded text-white text-center text-xs" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              <ToggleRow label="抽取规则" value={extractConfig.extractRule} onChange={(v) => updateField("extractRule", v)} />
              {extractConfig.extractRule && ruleGroups && (
                <div className="pl-3 space-y-1.5 max-h-40 overflow-y-auto">
                  <p className="text-[10px] text-[#666666] mb-1">选择抽取来源（可多选）</p>
                  {ruleGroups.map((g: any) => (
                    <label key={g.id} className="flex items-center gap-2 cursor-pointer">
                      <div className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${
                        extractConfig.ruleGroupIds.includes(g.id)
                          ? "bg-[#FF4655] border-[#FF4655]"
                          : "border-[#3A3A3A] bg-[#232323]"
                      }`}>
                        {extractConfig.ruleGroupIds.includes(g.id) && <Check className="w-3 h-3 text-white" />}
                      </div>
                      <input
                        type="checkbox"
                        className="sr-only"
                        checked={extractConfig.ruleGroupIds.includes(g.id)}
                        onChange={(e) => {
                          setExtractConfig((c) => {
                            if (e.target.checked) {
                              return { ...c, ruleGroupIds: [...c.ruleGroupIds, g.id] };
                            } else {
                              const next = c.ruleGroupIds.filter((id) => id !== g.id);
                              if (next.length === 0) return c; // keep at least one
                              return { ...c, ruleGroupIds: next };
                            }
                          });
                        }}
                      />
                      <span className="text-xs text-[#A0A0A0]">{g.name}</span>
                      <span className="text-[10px] text-[#666666]">({g.ruleCount}条)</span>
                    </label>
                  ))}
                </div>
              )}
              <ToggleRow label="卧底模式" value={extractConfig.undercoverEnabled} onChange={(v) => updateField("undercoverEnabled", v)} />
              {extractConfig.undercoverEnabled && (
                <div className="pl-3">
                  <label className="text-xs text-[#A0A0A0]">每队卧底数</label>
                  <input type="number" min={1} max={2} value={extractConfig.undercoverPerTeam} onChange={(e) => updateField("undercoverPerTeam", Number(e.target.value))} className="w-full mt-0.5 px-2 py-1 bg-[#232323] border border-[#3A3A3A] rounded text-white text-xs" />
                </div>
              )}
              <button onClick={handleExtract} disabled={isExtracting} className="w-full py-2 bg-[#FF4655] text-white text-sm font-semibold rounded-md hover:bg-[#E63E4C] disabled:opacity-50">
                {isExtracting ? "抽取中..." : "开始抽取"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Player Options Modal - permission-based */}
      {optionPlayer && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm">
          <div className="bg-[#1A1A1A] border border-[#3A3A3A] rounded-t-xl sm:rounded-xl p-5 w-full max-w-xs sm:mx-4 animate-slide-up">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <img src={optionPlayer.avatar || "/avatars/default-1.jpg"} alt="" className="w-8 h-8 rounded-full object-cover border border-[#3A3A3A]"
                  onError={(e) => { (e.target as HTMLImageElement).src = "/avatars/default-1.jpg"; }} />
                <span className="text-white font-medium text-sm">{optionPlayer.nickname}</span>
                {optionPlayer.isAdmin && <Star className="w-3 h-3 text-[#D4AF37] fill-[#D4AF37]" />}
              </div>
              <button onClick={() => setOptionPlayer(null)} className="p-1 rounded hover:bg-[#232323]"><X className="w-4 h-4 text-[#A0A0A0]" /></button>
            </div>
            <div className="space-y-2">
              {/* Host: Set/Unset Admin */}
              {isHost && (
                <button
                  onClick={() => { setAdmin.mutate({ playerId: optionPlayer.id, isAdmin: !optionPlayer.isAdmin }); setOptionPlayer(null); }}
                  className="w-full flex items-center gap-2 px-3 py-2.5 rounded-lg bg-[#232323] hover:bg-[#2E2E2E] text-white text-sm transition-colors"
                >
                  {optionPlayer.isAdmin ? <UserX className="w-4 h-4 text-[#FF4655]" /> : <UserCheck className="w-4 h-4 text-[#22C55E]" />}
                  <span>{optionPlayer.isAdmin ? "取消管理员" : "设为管理员"}</span>
                </button>
              )}

              {/* Everyone: Swap Position */}
              <button
                onClick={() => { setSwapTarget(optionPlayer); setOptionPlayer(null); }}
                className="w-full flex items-center gap-2 px-3 py-2.5 rounded-lg bg-[#232323] hover:bg-[#2E2E2E] text-white text-sm transition-colors"
              >
                <ArrowRightLeft className="w-4 h-4 text-[#3B82F6]" />
                <span>交换座位</span>
              </button>

              {/* Host or Admin: Kick */}
              {(isHost || isAdmin) && (
                <button
                  onClick={() => { if (confirm(`确定将 ${optionPlayer.nickname} 踢出房间？`)) { kickPlayer.mutate({ playerId: optionPlayer.id }); setOptionPlayer(null); } }}
                  className="w-full flex items-center gap-2 px-3 py-2.5 rounded-lg bg-[#FF4655]/10 hover:bg-[#FF4655]/20 text-[#FF4655] text-sm transition-colors"
                >
                  <UserX className="w-4 h-4" />
                  <span>踢出房间</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Booking Detail Modal */}
      {showBookingDetail && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm">
          <div className="bg-[#1A1A1A] border border-[#3A3A3A] rounded-t-xl sm:rounded-xl p-5 w-full max-w-xs sm:mx-4 animate-slide-up">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-white text-sm font-bold">{showBookingDetail} 详情</h2>
              <button onClick={() => setShowBookingDetail(null)} className="p-1 rounded hover:bg-[#232323]"><X className="w-4 h-4 text-[#A0A0A0]" /></button>
            </div>
            {bookingDetail && bookingDetail.users && bookingDetail.users.length > 0 ? bookingDetail.users.map((u: any) => (
              <div key={u.id} className="flex items-center gap-2 py-1.5 border-b border-[#232323] last:border-0">
                <img src={u.avatar || "/avatars/default-1.jpg"} alt="" className="w-6 h-6 rounded-full object-cover" onError={(e) => { (e.target as HTMLImageElement).src = "/avatars/default-1.jpg"; }} />
                <span className="text-white text-xs">{u.nickname}</span>
              </div>
            )) : <p className="text-[#666666] text-xs text-center py-3">暂无预约</p>}
          </div>
        </div>
      )}
    </div>
  );
}

/* Compact Player Slot - Reference screenshot style */
function CompactSlot({ player, position: _position, onClick, onOption, currentUserId, isExtracting, hostId }: {
  player?: any; position: number; onClick: () => void; onOption?: () => void;
  currentUserId?: number; isExtracting: boolean; hostId?: number;
}) {
  const isSelf = player?.userId === currentUserId;
  const showUndercover = isSelf && player?.isUndercover;

  if (!player) {
    return (
      <div onClick={onClick} className="flex items-center gap-2 px-3 py-2 border border-dashed border-[#3A3A3A]/60 rounded-lg active:border-[#FF4655]/50 active:bg-[#FF4655]/5 cursor-pointer transition-all min-h-[48px]">
        <span className="text-[#666666] text-xs">空位</span>
      </div>
    );
  }

  // Player is host -> only show Crown, not Admin star
  const isHostPlayer = player.userId === hostId;
  // Can NOT open options on self or host
  const canOption = !isHostPlayer && !isSelf;

  return (
    <motion.div layout
      className={`group relative flex items-center gap-2.5 px-3 py-2 rounded-lg border transition-all ${
        showUndercover ? "bg-[#8B5CF6]/5 border-[#8B5CF6]/50" : isSelf ? "bg-[#1E1E1E] border-[#FF4655]" : "bg-[#1E1E1E] border-[#2A2A2A] hover:border-[#3A3A3A]"
      } ${isExtracting ? "animate-pulse" : ""}`}>
      {/* Avatar */}
      <div className="relative flex-shrink-0 self-start" onClick={onClick}>
        <img src={player.avatar || "/avatars/default-1.jpg"} alt=""
          className={`w-9 h-9 rounded-full object-cover border-2 ${isSelf ? "border-[#FF4655]" : "border-[#3A3A3A]"}`}
          onError={(e) => { (e.target as HTMLImageElement).src = "/avatars/default-1.jpg"; }} />
        {isSelf && <span className="absolute -bottom-0.5 -right-0.5 px-1 py-0 bg-[#FF4655] text-white text-[8px] rounded font-bold">我</span>}
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0 overflow-hidden" onClick={onClick}>
        {/* Row 1: Nickname + Role badges + Agent */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-white text-sm font-semibold truncate">{player.nickname}</span>
          {isHostPlayer && <Crown className="w-3 h-3 text-[#D4AF37] flex-shrink-0" />}
          {!isHostPlayer && player.isAdmin && <Star className="w-3 h-3 text-[#D4AF37] fill-[#D4AF37] flex-shrink-0" />}
          {showUndercover && <EyeOff className="w-3 h-3 text-[#8B5CF6] flex-shrink-0" />}

          <AnimatePresence mode="wait">
            {player.agent && (
              <motion.span key={player.agent.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                className="flex items-center gap-1 flex-shrink-0 ml-1">
                <span className="w-2 h-2 rounded-full inline-block" style={{ backgroundColor: player.agent.color }} />
                <span className="text-[11px] font-medium" style={{ color: player.agent.color }}>{player.agent.name}</span>
                <span className="text-[9px] px-1 py-0 rounded" style={{ backgroundColor: `${ROLE_COLORS[player.agent.role]}20`, color: ROLE_COLORS[player.agent.role] }}>
                  {ROLE_LABELS[player.agent.role]}
                </span>
              </motion.span>
            )}
          </AnimatePresence>
        </div>

        {/* Row 2: Rule name + Rule content - truncate */}
        {player.rule && (
          <div className="flex items-center gap-1 mt-0.5 min-w-0 overflow-hidden">
            <span className="text-xs font-bold text-[#FF4655] whitespace-nowrap flex-shrink-0">{player.rule.name}</span>
            <span className="text-xs text-[#A0A0A0] truncate">{player.rule.content}</span>
          </div>
        )}
      </div>

      {/* Options button - MoreHorizontal icon */}
      {canOption && (
        <button
          onClick={(e) => { e.stopPropagation(); onOption?.(); }}
          className="p-1 rounded-md text-[#A0A0A0] active:text-[#FF4655] active:bg-[#FF4655]/20 transition-colors flex-shrink-0"
        >
          <MoreHorizontal className="w-4 h-4" />
        </button>
      )}
    </motion.div>
  );
}

function ToggleRow({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-white text-sm">{label}</span>
      <button onClick={() => onChange(!value)} className={`relative w-10 h-5 rounded-full transition-colors ${value ? "bg-[#FF4655]" : "bg-[#3A3A3A]"}`}>
        <span className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${value ? "translate-x-5" : ""}`} />
      </button>
    </div>
  );
}
