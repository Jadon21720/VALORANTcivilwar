import { useState } from "react";
import {
  Swords, Shuffle,
  Users, CalendarDays, BookOpen, ChevronRight, ChevronDown,
  MessageCircle
} from "lucide-react";

interface SectionProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  defaultOpen?: boolean;
}

function Section({ title, icon, children, defaultOpen = false }: SectionProps) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border border-[#3A3A3A] rounded-lg overflow-hidden">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between px-4 py-3 bg-[#1A1A1A] hover:bg-[#232323] transition-colors"
      >
        <div className="flex items-center gap-2">
          {icon}
          <span className="text-white font-semibold text-sm">{title}</span>
        </div>
        {open ? <ChevronDown className="w-4 h-4 text-[#A0A0A0]" /> : <ChevronRight className="w-4 h-4 text-[#A0A0A0]" />}
      </button>
      {open && (
        <div className="px-4 py-4 bg-[#0F0F0F] space-y-3">
          {children}
        </div>
      )}
    </div>
  );
}

function Step({ number, title, children }: { number: number; title: string; children: React.ReactNode }) {
  return (
    <div className="flex gap-3">
      <div className="flex-shrink-0 w-6 h-6 rounded-full bg-[#FF4655] flex items-center justify-center text-white text-xs font-bold mt-0.5">
        {number}
      </div>
      <div className="flex-1">
        <h4 className="text-white text-sm font-medium mb-1">{title}</h4>
        <div className="text-[#A0A0A0] text-xs leading-relaxed">{children}</div>
      </div>
    </div>
  );
}

export default function Guide() {
  return (
    <div className="max-w-2xl mx-auto px-4 py-6 space-y-4">
      {/* Header */}
      <div className="text-center mb-6">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-[#FF4655]/10 rounded-full mb-3">
          <BookOpen className="w-4 h-4 text-[#FF4655]" />
          <span className="text-[#FF4655] text-sm font-medium">使用指南</span>
        </div>
        <h1 className="text-white text-2xl font-bold mb-2">无畏契约娱乐内战组队平台</h1>
      </div>

      {/* Basic Flow */}
      <Section title="完整流程" icon={<Swords className="w-4 h-4 text-[#FF4655]" />} defaultOpen={true}>
        <div className="space-y-4">
          <Step number={1} title="登录">
            点击右上角登录按钮，使用平台账号登录。
          </Step>
          <Step number={2} title="设置昵称和头像">
            进入「个人设置」页面，修改昵称并选择游戏头像。
          </Step>
          <Step number={3} title="创建或加入房间">
            在大厅点击「创建房间」，房间码可自定义或留空自动生成。也可通过房间码搜索加入已有房间。
          </Step>
          <Step number={4} title="分配队伍">
            房主点击「分配」按钮，所有非观众席的玩家会被随机打乱分为红方（防守）和蓝方（进攻），每队5人。
          </Step>
          <Step number={5} title="抽取角色和规则">
            房主点击「抽取」按钮，配置角色类型数量和规则来源分组，确认后开始抽取。每个玩家会随机分配到角色和规则。
          </Step>
        </div>
      </Section>

      {/* Room Operations */}
      <Section title="房间操作" icon={<Users className="w-4 h-4 text-[#FF4655]" />}>
        <div className="space-y-3 text-[#A0A0A0] text-xs leading-relaxed">
          <p><b className="text-white">创建房间：</b>大厅页面点击「创建房间」，填写房间码（留空自动生成）和房间名称，点击创建。</p>
          <p><b className="text-white">加入房间：</b>点击大厅中的房间卡片加入，或通过搜索房间码加入。</p>
          <p><b className="text-white">修改房间信息：</b>房主点击房间名称旁的编辑图标，可修改房间名和房间码。管理员只能修改房间名。</p>
          <p><b className="text-white">移动座位：</b>点击空座位移动到该位置。点击有人的座位发起交换申请。</p>
          <p><b className="text-white">座位选项：</b>每个座位后方有「选项」按钮，房主可添加管理员/交换/踢出，管理员可交换/踢出，普通玩家仅可交换。</p>
          <p><b className="text-white">观众席：</b>新加入的玩家默认在观众席。点击观众席中的玩家头像可将其分配到空座位。</p>
          <p><b className="text-white">退出房间：</b>普通玩家直接退出。房主退出时需选择解散房间或将房主转让给指定玩家。</p>
        </div>
      </Section>

      {/* Extract */}
      <Section title="抽取配置" icon={<Shuffle className="w-4 h-4 text-[#FF4655]" />}>
        <div className="space-y-3 text-[#A0A0A0] text-xs leading-relaxed">
          <p><b className="text-white">抽取角色：</b>开启后可分别设置红方和蓝方的决斗、先锋、控场、哨卫数量，每队总和需为5。</p>
          <p><b className="text-white">抽取规则：</b>开启后可多选规则分组作为抽取来源，系统从所有选中分组中随机抽取。</p>
          <p><b className="text-white">卧底模式：</b>开启后每队指定数量的玩家会被标记为卧底，仅自己可见。</p>
          <p><b className="text-white">清除抽取：</b>抽取完成后可点击「清除抽取」重新抽取。</p>
        </div>
      </Section>

      {/* Rules */}
      <Section title="规则管理" icon={<BookOpen className="w-4 h-4 text-[#FF4655]" />}>
        <div className="space-y-3 text-[#A0A0A0] text-xs leading-relaxed">
          <p><b className="text-white">新建分组：</b>点击「新建分组」创建自己的规则分组。新建分组默认置顶，可通过上下箭头调整排序。</p>
          <p><b className="text-white">新建规则：</b>选择分组后点击「新建」，输入规则名称和内容。</p>
          <p><b className="text-white">编辑规则：</b>点击规则右侧的编辑图标修改名称、内容或移动到其它分组。</p>
          <p><b className="text-white">批量导入：</b>点击「批量导入」，每行输入一条规则的名称和内容（用空格分隔）。</p>
          <p><b className="text-white">多选操作：</b>点击规则左侧复选框多选，支持批量复制、移动到其它分组、删除。</p>
          <p><b className="text-white">预置分组：</b>预置分组仅管理员可编辑和添加规则。普通用户删除预置分组仅对自己隐藏，可在「已隐藏的分组」中恢复。</p>
        </div>
      </Section>

      {/* Booking */}
      <Section title="预约" icon={<CalendarDays className="w-4 h-4 text-[#FF4655]" />}>
        <div className="space-y-3 text-[#A0A0A0] text-xs leading-relaxed">
          <p>内战需要10人，预约功能用于查看大家什么时候有空，方便协调对战时间。</p>
          <p><b className="text-white">选择日期：</b>点击日历选择日期，下方显示该日期的所有时间段。</p>
          <p><b className="text-white">预约时段：</b>每个时间段为2小时，点击「预约」标记你有空的时间。</p>
          <p><b className="text-white">取消预约：</b>已预约的时间段显示绿色，点击「取消」可撤销。</p>
          <p><b className="text-white">查看他人：</b>每个时间段显示已预约的人数，点击数字可查看具体是哪些人。</p>
        </div>
      </Section>

      {/* Contact */}
      <div className="border border-[#3A3A3A] rounded-lg p-4 bg-[#1A1A1A]">
        <div className="flex items-center gap-2 mb-2">
          <MessageCircle className="w-4 h-4 text-[#FF4655]" />
          <span className="text-white text-sm font-medium">联系我们</span>
        </div>
        <p className="text-[#A0A0A0] text-xs leading-relaxed">
          在使用过程中，若您遇到任何问题、有优化建议或组队开黑，都可加入 QQ 群：745772965，欢迎进群交流。
        </p>
      </div>
    </div>
  );
}
