import { useState } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Search, Plus, Users, Crown, LogIn, X, Swords } from "lucide-react";

export default function Home() {
  const { isAuthenticated, user } = useAuth();
  const navigate = useNavigate();
  const utils = trpc.useUtils();
  const [search, setSearch] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [roomCode, setRoomCode] = useState("");
  const [roomName, setRoomName] = useState("");
  const [modalError, setModalError] = useState("");
  const [isComposing, setIsComposing] = useState(false);

  const { data: rooms, isLoading } = trpc.room.list.useQuery(
    search ? { search } : undefined
  );

  const createRoom = trpc.room.create.useMutation({
    onSuccess: (data) => {
      utils.room.list.invalidate();
      utils.auth.me.invalidate();
      setModalError("");
      navigate(`/room/${data.code}`);
    },
    onError: (err) => setModalError(err.message),
  });

  const joinRoom = trpc.room.join.useMutation({
    onSuccess: (_, vars) => {
      utils.room.list.invalidate();
      navigate(`/room/${vars.code}`);
    },
    onError: (err) => { console.error(err.message); },
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    setModalError("");
    const code = roomCode.toUpperCase().trim();
    const name = roomName.trim() || undefined;

    if (code && !/^[A-Z]{3}\d{3}$/.test(code)) {
      setModalError("房间码格式为3个大写字母+3个数字，如ABC123");
      return;
    }

    if (!code) {
      createRoom.mutate({ name });
    } else {
      createRoom.mutate({ code, name });
    }
  };

  const handleJoin = (code: string) => {
    if (!isAuthenticated) {
      navigate("/login");
      return;
    }
    joinRoom.mutate({ code });
  };

  // Sort: joined room first
  const sortedRooms = rooms?.slice().sort((a, b) => {
    const aJoined = user?.currentRoomCode === a.code ? 1 : 0;
    const bJoined = user?.currentRoomCode === b.code ? 1 : 0;
    return bJoined - aJoined;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      {/* Search & Create Bar */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#666666]" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="搜索房间名或房间码..."
            className="w-full pl-10 pr-4 py-2.5 bg-[#1A1A1A] border border-[#3A3A3A] rounded-md text-white placeholder-[#666666] text-sm focus:outline-none focus:border-[#FF4655] focus:ring-1 focus:ring-[#FF4655]/30 transition-all"
          />
        </div>
        <button
          onClick={() => { setShowCreate(true); setModalError(""); setRoomCode(""); setRoomName(""); }}
          className="flex items-center justify-center gap-2 px-5 py-2.5 bg-[#FF4655] text-white text-sm font-semibold rounded-md hover:bg-[#E63E4C] hover:shadow-[0_0_12px_rgba(255,70,85,0.4)] transition-all active:scale-[0.98]"
        >
          <Plus className="w-4 h-4" />
          创建房间
        </button>
      </div>

      {/* Room List */}
      {isLoading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="h-36 bg-[#1A1A1A] rounded-lg animate-pulse" />
          ))}
        </div>
      ) : sortedRooms && sortedRooms.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
          {sortedRooms.map((room) => {
            const isJoined = user?.currentRoomCode === room.code;
            return (
              <div
                key={room.code}
                onClick={() => isJoined ? navigate(`/room/${room.code}`) : handleJoin(room.code)}
                className={`relative bg-[#1A1A1A] border rounded-lg p-4 cursor-pointer transition-all hover:border-[#FF4655] group ${
                  isJoined ? "border-l-[3px] border-l-[#FF4655] border-[#3A3A3A]" : "border-[#3A3A3A]"
                }`}
              >
                {isJoined && (
                  <span className="absolute top-2 right-2 px-2 py-0.5 bg-[#FF4655] text-white text-[10px] font-bold rounded">
                    已加入
                  </span>
                )}
                <h3 className="text-white font-semibold text-base mb-2 pr-16 truncate">
                  {room.name}
                </h3>
                <div className="flex items-center gap-2 mb-3">
                  <span className="px-2 py-0.5 bg-[#D4AF37]/10 text-[#D4AF37] text-xs font-mono rounded">
                    {room.code}
                  </span>
                  <span className="flex items-center gap-1 text-[#A0A0A0] text-xs">
                    <Users className="w-3 h-3" />
                    {room.playerCount}/{room.maxPlayers}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <img
                    src={room.hostAvatar || "/avatars/default-1.jpg"}
                    alt=""
                    className="w-5 h-5 rounded-full object-cover border border-[#3A3A3A]"
                    onError={(e) => { (e.target as HTMLImageElement).src = "/avatars/default-1.jpg"; }}
                  />
                  <span className="text-[#A0A0A0] text-xs truncate flex items-center gap-1">
                    <Crown className="w-3 h-3 text-[#D4AF37]" />
                    {room.hostName}
                  </span>
                </div>
                {!isJoined && (
                  <div className="absolute inset-0 bg-[#FF4655]/0 group-hover:bg-[#FF4655]/5 rounded-lg flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all">
                    <span className="flex items-center gap-1 text-[#FF4655] text-sm font-medium bg-[#0F0F0F]/80 px-3 py-1.5 rounded-full">
                      <LogIn className="w-4 h-4" />
                      加入房间
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-20">
          <div className="w-20 h-20 mb-4 flex items-center justify-center bg-[#1A1A1A] rounded-full">
            <Swords className="w-10 h-10 text-[#3A3A3A]" />
          </div>
          <p className="text-[#A0A0A0] text-base mb-4">暂无房间，创建一个开始战斗吧！</p>
          <button
            onClick={() => setShowCreate(true)}
            className="flex items-center gap-2 px-5 py-2.5 bg-[#FF4655] text-white text-sm font-semibold rounded-md hover:bg-[#E63E4C] transition-all"
          >
            <Plus className="w-4 h-4" />
            创建房间
          </button>
        </div>
      )}

      {/* Create Room Modal */}
      {showCreate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm">
          <div className="bg-[#1A1A1A] border border-[#3A3A3A] rounded-xl p-6 w-full max-w-md mx-4 animate-slide-up">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-white text-xl font-bold">创建房间</h2>
              <button
                onClick={() => { setShowCreate(false); setModalError(""); }}
                className="p-1 rounded-md hover:bg-[#232323] transition-colors"
              >
                <X className="w-5 h-5 text-[#A0A0A0]" />
              </button>
            </div>
            <form onSubmit={handleCreate} className="space-y-3">
              {modalError && (
                <div className="px-3 py-2 bg-[#FF4655]/10 border border-[#FF4655]/30 rounded-md text-[#FF4655] text-sm">
                  {modalError}
                </div>
              )}

              <div>
                <label className="block text-sm text-[#A0A0A0] mb-1.5">房间码</label>
                <input
                  type="text"
                  value={roomCode}
                  onChange={(e) => { if (!isComposing) setRoomCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6)); }}
                  onCompositionStart={() => setIsComposing(true)}
                  onCompositionEnd={(e) => { setIsComposing(false); setRoomCode((e.target as HTMLInputElement).value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6)); }}
                  placeholder="留空则自动生成，如 ABC123"
                  maxLength={6}
                  className="w-full px-3 py-2.5 bg-[#232323] border border-[#3A3A3A] rounded-md text-white placeholder-[#666666] text-sm font-mono tracking-wider focus:outline-none focus:border-[#FF4655] focus:ring-1 focus:ring-[#FF4655]/30 transition-all"
                />
                <p className="text-[#666666] text-xs mt-1">格式：3个大写字母 + 3个数字，留空则自动生成</p>
              </div>
              <div>
                <label className="block text-sm text-[#A0A0A0] mb-1.5">房间名称</label>
                <input
                  type="text"
                  value={roomName}
                  onChange={(e) => setRoomName(e.target.value)}
                  placeholder={`房间 ${roomCode || "ABC123"}`}
                  maxLength={50}
                  className="w-full px-3 py-2.5 bg-[#232323] border border-[#3A3A3A] rounded-md text-white placeholder-[#666666] text-sm focus:outline-none focus:border-[#FF4655] focus:ring-1 focus:ring-[#FF4655]/30 transition-all"
                />
              </div>
              <button
                type="submit"
                disabled={createRoom.isPending}
                className="w-full py-2.5 bg-[#FF4655] text-white text-sm font-semibold rounded-md hover:bg-[#E63E4C] hover:shadow-[0_0_12px_rgba(255,70,85,0.4)] transition-all disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98]"
              >
                {createRoom.isPending ? "创建中..." : "创建"}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
