import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { User, Camera, Upload } from "lucide-react";

const FALLBACK_AVATAR = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Crect fill='%23232323' width='100' height='100'/%3E%3Ccircle cx='50' cy='40' r='20' fill='%23FF4655'/%3E%3Cpath d='M20 85 Q50 60 80 85' fill='%23FF4655'/%3E%3C/svg%3E";

export default function Settings() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const navigate = useNavigate();
  const utils = trpc.useUtils();
  const fileRef = useRef<HTMLInputElement>(null);

  const [nickname, setNickname] = useState("");
  const [avatarPreview, setAvatarPreview] = useState("");
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (user) {
      setNickname(user.nickname || user.name || "");
      setAvatarPreview(user.gameAvatar || user.avatar || FALLBACK_AVATAR);
    }
  }, [user]);

  const updateProfile = trpc.auth.updateProfile.useMutation({
    onSuccess: () => {
      utils.auth.me.invalidate();
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      alert("图片大小不能超过2MB");
      return;
    }
    const reader = new FileReader();
    reader.onloadend = () => setAvatarPreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const updateData: { nickname?: string; gameAvatar?: string } = {};
    if (nickname.trim()) updateData.nickname = nickname.trim();
    if (avatarPreview && avatarPreview !== (user?.gameAvatar || user?.avatar || FALLBACK_AVATAR)) {
      updateData.gameAvatar = avatarPreview;
    }
    if (Object.keys(updateData).length > 0) {
      updateProfile.mutate(updateData);
    }
  };

  if (authLoading) {
    return (
      <div className="max-w-md mx-auto px-4 py-20">
        <div className="h-64 bg-[#1A1A1A] rounded-lg animate-pulse" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto px-4 py-20 text-center">
        <User className="w-12 h-12 text-[#3A3A3A] mx-auto mb-4" />
        <p className="text-[#A0A0A0] text-lg mb-4">请先登录</p>
        <button onClick={() => navigate("/login")} className="px-4 py-2 bg-[#FF4655] text-white rounded-md text-sm hover:bg-[#E63E4C]">
          去登录
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto px-4 py-8">
      <div className="bg-[#1A1A1A] border border-[#3A3A3A] rounded-xl p-6">
        <h1 className="text-white text-xl font-bold mb-1">个人设置</h1>
        <p className="text-[#A0A0A0] text-sm mb-6">修改你的头像和昵称</p>

        <form onSubmit={handleSave} className="space-y-6">
          {/* Avatar Upload */}
          <div className="flex flex-col items-center">
            <div className="relative mb-4" onClick={() => fileRef.current?.click()}>
              <img
                src={avatarPreview || FALLBACK_AVATAR}
                alt="avatar"
                className="w-24 h-24 rounded-full object-cover border-2 border-[#FF4655] cursor-pointer"
                onError={(e) => { (e.target as HTMLImageElement).src = FALLBACK_AVATAR; }}
              />
              <div className="absolute bottom-0 right-0 w-8 h-8 bg-[#FF4655] rounded-full flex items-center justify-center border-2 border-[#1A1A1A] cursor-pointer">
                <Camera className="w-4 h-4 text-white" />
              </div>
            </div>
            <input ref={fileRef} type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#232323] border border-[#3A3A3A] rounded-md text-[#A0A0A0] text-xs hover:text-white hover:border-[#4A4A4A] transition-colors"
            >
              <Upload className="w-3.5 h-3.5" />
              上传头像
            </button>
            <p className="text-[#666666] text-[10px] mt-1">支持 JPG/PNG，最大2MB</p>
          </div>

          {/* Nickname */}
          <div>
            <label className="block text-sm text-[#A0A0A0] mb-1.5">游戏昵称</label>
            <input type="text" value={nickname} onChange={(e) => setNickname(e.target.value)}
              placeholder="输入你的游戏昵称" maxLength={16}
              className="w-full px-3 py-2.5 bg-[#232323] border border-[#3A3A3A] rounded-md text-white placeholder-[#666666] text-sm focus:outline-none focus:border-[#FF4655] focus:ring-1 focus:ring-[#FF4655]/30 transition-all" />
          </div>

          {/* Save Button */}
          <button type="submit" disabled={updateProfile.isPending}
            className={`w-full py-2.5 text-sm font-semibold rounded-md transition-all active:scale-[0.98] ${
              saved ? "bg-[#22C55E] text-white" : "bg-[#FF4655] text-white hover:bg-[#E63E4C] hover:shadow-[0_0_12px_rgba(255,70,85,0.4)]"
            } disabled:opacity-50`}>
            {saved ? "已保存！" : updateProfile.isPending ? "保存中..." : "保存"}
          </button>
        </form>
      </div>
    </div>
  );
}
