import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import {
  Plus, Pencil, Trash2, Search, X, ChevronRight,
  FileText, FolderOpen, Upload, FolderPlus, Copy, CheckSquare, Square, Check,
  Move, EyeOff
} from "lucide-react";

export default function Rules() {
  const { isAuthenticated, user } = useAuth();
  const utils = trpc.useUtils();

  const [selectedGroup, setSelectedGroup] = useState<number | null>(null);
  const [search, setSearch] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [showEdit, setShowEdit] = useState<number | null>(null);
  const [showBulkImport, setShowBulkImport] = useState(false);
  const [showCreateGroup, setShowCreateGroup] = useState(false);
  const [editingGroup, setEditingGroup] = useState<number | null>(null);
  const [editingGroupName, setEditingGroupName] = useState("");

  // Multi-select states
  const [selectedRuleIds, setSelectedRuleIds] = useState<Set<number>>(new Set());
  const [showCopyModal, setShowCopyModal] = useState(false);
  const [showMoveModal, setShowMoveModal] = useState(false);
  const [copyTargetGroupId, setCopyTargetGroupId] = useState<number>(0);
  const [moveTargetGroupId, setMoveTargetGroupId] = useState<number>(0);

  // Form states
  const [ruleName, setRuleName] = useState("");
  const [ruleContent, setRuleContent] = useState("");
  const [ruleGroupId, setRuleGroupId] = useState<number>(1);
  const [groupName, setGroupName] = useState("");
  const [bulkText, setBulkText] = useState("");

  // Public queries: available without login
  const { data: groups } = trpc.rule.listGroups.useQuery();

  const { data: rules } = trpc.rule.listRules.useQuery(
    { groupId: selectedGroup || undefined, search: search || undefined }
  );

  // Auth-only queries
  const { data: hiddenGroups } = trpc.rule.listHiddenGroups.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const createRule = trpc.rule.createRule.useMutation({
    onSuccess: () => {
      utils.rule.listRules.invalidate();
      setShowCreate(false);
      resetForm();
    },
  });

  const updateRule = trpc.rule.updateRule.useMutation({
    onSuccess: () => {
      utils.rule.listRules.invalidate();
      setShowEdit(null);
      resetForm();
    },
  });

  const deleteRule = trpc.rule.deleteRule.useMutation({
    onSuccess: () => {
      utils.rule.listRules.invalidate();
      setSelectedRuleIds((prev) => {
        const next = new Set(prev);
        // Remove deleted rule IDs
        return next;
      });
    },
  });

  const createGroup = trpc.rule.createGroup.useMutation({
    onSuccess: () => {
      utils.rule.listGroups.invalidate();
      setShowCreateGroup(false);
      setGroupName("");
    },
  });

  const deleteGroup = trpc.rule.deleteGroup.useMutation({
    onSuccess: () => {
      utils.rule.listGroups.invalidate();
      utils.rule.listHiddenGroups.invalidate();
      if (selectedGroup) setSelectedGroup(null);
    },
  });

  const restoreGroup = trpc.rule.restoreGroup.useMutation({
    onSuccess: () => {
      utils.rule.listGroups.invalidate();
      utils.rule.listHiddenGroups.invalidate();
    },
  });

  const updateGroup = trpc.rule.updateGroup.useMutation({
    onSuccess: () => {
      utils.rule.listGroups.invalidate();
      setEditingGroup(null);
      setEditingGroupName("");
    },
  });

  const bulkImport = trpc.rule.bulkImport.useMutation({
    onSuccess: () => {
      utils.rule.listRules.invalidate();
      setShowBulkImport(false);
      setBulkText("");
    },
  });

  const copyRules = trpc.rule.copyRules.useMutation({
    onSuccess: () => {
      utils.rule.listRules.invalidate();
      utils.rule.listGroups.invalidate();
      setShowCopyModal(false);
      setSelectedRuleIds(new Set());
    },
  });

  const moveRules = trpc.rule.moveRules.useMutation({
    onSuccess: () => {
      utils.rule.listRules.invalidate();
      utils.rule.listGroups.invalidate();
      setShowMoveModal(false);
      setSelectedRuleIds(new Set());
    },
  });

  const bulkDeleteRules = trpc.rule.bulkDeleteRules.useMutation({
    onSuccess: () => {
      utils.rule.listRules.invalidate();
      utils.rule.listGroups.invalidate();
      setSelectedRuleIds(new Set());
    },
  });

  const resetForm = () => {
    setRuleName("");
    setRuleContent("");
    setRuleGroupId(1);
  };

  const toggleRuleSelection = (ruleId: number) => {
    setSelectedRuleIds((prev) => {
      const next = new Set(prev);
      if (next.has(ruleId)) {
        next.delete(ruleId);
      } else {
        next.add(ruleId);
      }
      return next;
    });
  };

  const selectAll = () => {
    if (!rules) return;
    if (selectedRuleIds.size === rules.length) {
      setSelectedRuleIds(new Set());
    } else {
      setSelectedRuleIds(new Set(rules.map((r) => r.id)));
    }
  };

  const canEditRule = (rule: any) => user?.role === "admin" || rule.userId;
  const canDeleteRule = (rule: any) => user?.role === "admin" || rule.userId;

  const handleCreateRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ruleName.trim() || !ruleContent.trim()) return;
    createRule.mutate({ name: ruleName.trim(), content: ruleContent.trim(), groupId: ruleGroupId });
  };

  const handleUpdateRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ruleName.trim() || !ruleContent.trim() || !showEdit) return;
    updateRule.mutate({ id: showEdit, name: ruleName.trim(), content: ruleContent.trim(), groupId: ruleGroupId });
  };

  const openEdit = (rule: any) => {
    setRuleName(rule.name);
    setRuleContent(rule.content);
    setRuleGroupId(rule.groupId);
    setShowEdit(rule.id);
    setShowCreate(false);
  };

  const handleBulkImport = (e: React.FormEvent) => {
    e.preventDefault();
    const lines = bulkText.split("\n").filter((l) => l.trim());
    const parsed = lines.map((line) => {
      const parts = line.split(/[|，,]/).map((p) => p.trim());
      if (parts.length >= 2) return { name: parts[0], content: parts[1] };
      const spaceIdx = line.indexOf(" ");
      if (spaceIdx > 0) return { name: line.slice(0, spaceIdx), content: line.slice(spaceIdx + 1) };
      return null;
    }).filter(Boolean) as { name: string; content: string }[];

    if (parsed.length === 0) return;
    bulkImport.mutate({ rules: parsed, groupId: ruleGroupId });
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Sidebar - Groups */}
        <div className="lg:w-56 flex-shrink-0">
          <div className="bg-[#1A1A1A] border border-[#3A3A3A] rounded-lg p-3">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-white font-semibold text-sm flex items-center gap-1.5">
                <FolderOpen className="w-4 h-4 text-[#A0A0A0]" />
                规则分组
              </h3>
              {isAuthenticated && (
                <button onClick={() => setShowCreateGroup(true)} className="p-1 rounded hover:bg-[#232323]" title="新建分组">
                  <FolderPlus className="w-4 h-4 text-[#A0A0A0]" />
                </button>
              )}
            </div>
            <div className="space-y-0.5">
              <button
                onClick={() => { setSelectedGroup(null); setSelectedRuleIds(new Set()); }}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-sm transition-colors ${
                  selectedGroup === null
                    ? "bg-[#232323] text-[#FF4655] border-l-[3px] border-l-[#FF4655]"
                    : "text-[#A0A0A0] hover:bg-[#232323] hover:text-white"
                }`}
              >
                <span>全部</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
              {groups?.map((group) => (
                <button
                  key={group.id}
                  onClick={() => { setSelectedGroup(group.id); setSelectedRuleIds(new Set()); }}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-sm transition-colors ${
                    selectedGroup === group.id
                      ? "bg-[#232323] text-[#FF4655] border-l-[3px] border-l-[#FF4655]"
                      : "text-[#A0A0A0] hover:bg-[#232323] hover:text-white"
                  }`}
                >
                  <span className="truncate flex-1 text-left">{group.name}</span>
                  <div className="flex items-center gap-1">
                    <span className="text-[#666666] text-xs">{group.ruleCount}</span>
                    {/* Edit button: own groups always, preset only for admin; hide when not logged in */}
                    {isAuthenticated && (group.userId || user?.role === "admin") && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setEditingGroup(group.id);
                          setEditingGroupName(group.name);
                        }}
                        className="p-0.5 rounded hover:bg-[#FF4655]/20 transition-all"
                      >
                        <Pencil className="w-3 h-3 text-[#A0A0A0]" />
                      </button>
                    )}
                    {/* Delete button: own groups for logged-in users, preset groups for admin or hide */}
                    {group.userId && isAuthenticated && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (confirm(`确定删除分组"${group.name}"？\n该分组内 ${group.ruleCount} 条规则将被一并删除。`)) {
                            deleteGroup.mutate({ id: group.id });
                          }
                        }}
                        className="p-0.5 rounded hover:bg-[#FF4655]/20 transition-all"
                      >
                        <Trash2 className="w-3 h-3 text-[#FF4655]" />
                      </button>
                    )}
                    {!group.userId && isAuthenticated && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (user?.role === "admin") {
                            if (confirm(`【管理员】确定彻底删除预置分组"${group.name}"？\n该分组内 ${group.ruleCount} 条预置规则将被一并删除，所有用户将失去此分组。`)) {
                              deleteGroup.mutate({ id: group.id });
                            }
                          } else {
                            if (confirm(`确定隐藏预置分组"${group.name}"？\n隐藏后该分组将不再显示在您的列表中，可随时从"已隐藏的分组"中恢复。`)) {
                              deleteGroup.mutate({ id: group.id });
                            }
                          }
                        }}
                        className="p-0.5 rounded hover:bg-[#FF4655]/20 transition-all"
                      >
                        <Trash2 className="w-3 h-3 text-[#FF4655]" />
                      </button>
                    )}
                  </div>
                </button>
              ))}
            </div>

            {/* Hidden Preset Groups */}
            {hiddenGroups && hiddenGroups.length > 0 && (
              <div className="mt-4 pt-4 border-t border-[#3A3A3A]">
                <h4 className="text-[#666666] text-xs font-medium mb-2 px-1">已隐藏的分组</h4>
                <div className="space-y-0.5">
                  {hiddenGroups.map((group) => (
                    <div
                      key={group.id}
                      className="w-full flex items-center justify-between px-3 py-2 rounded-md text-sm text-[#666666] bg-[#151515]"
                    >
                      <div className="flex items-center gap-2 truncate flex-1">
                        <EyeOff className="w-3 h-3" />
                        <span className="truncate">{group.name}</span>
                        <span className="text-[#444444] text-xs">({group.ruleCount})</span>
                      </div>
                      <button
                        onClick={() => restoreGroup.mutate({ groupId: group.id })}
                        disabled={restoreGroup.isPending}
                        className="px-2 py-1 text-xs text-[#A0A0A0] hover:text-white hover:bg-[#232323] rounded transition-colors disabled:opacity-50"
                      >
                        恢复显示
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 min-w-0">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
            <h1 className="text-white text-xl font-bold">{isAuthenticated ? "我的规则" : "规则预览"}</h1>
            <div className="flex items-center gap-2">
              <div className="relative flex-1 sm:flex-none">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#666666]" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="搜索规则..."
                  className="w-full sm:w-48 pl-9 pr-3 py-2 bg-[#1A1A1A] border border-[#3A3A3A] rounded-md text-white placeholder-[#666666] text-sm focus:outline-none focus:border-[#FF4655]"
                />
              </div>
              {/* Only show create/import when logged in, and for non-preset groups or admin */}
              {isAuthenticated && (() => {
                const selectedGroupData = groups?.find((g: any) => g.id === selectedGroup);
                const isPresetGroup = selectedGroupData && !selectedGroupData.userId;
                if (isPresetGroup && user?.role !== "admin") return null;
                return (
                  <>
                    <button
                      onClick={() => setShowBulkImport(true)}
                      className="flex items-center gap-1.5 px-3 py-2 bg-[#232323] border border-[#3A3A3A] text-[#A0A0A0] text-sm rounded-md active:text-white active:border-[#4A4A4A] transition-colors"
                    >
                      <Upload className="w-4 h-4" />
                      <span className="hidden sm:inline">批量导入</span>
                    </button>
                    <button
                      onClick={() => { setShowCreate(true); resetForm(); setShowEdit(null); }}
                      className="flex items-center gap-1.5 px-3 py-2 bg-[#FF4655] text-white text-sm font-medium rounded-md active:bg-[#E63E4C] transition-colors"
                    >
                      <Plus className="w-4 h-4" />
                      <span className="hidden sm:inline">新建</span>
                    </button>
                  </>
                );
              })()}
            </div>
          </div>

          {/* Select All Bar - only when logged in */}
          {isAuthenticated && rules && rules.length > 0 && (
            <div className="flex items-center justify-between mb-3 px-1">
              <button onClick={selectAll} className="flex items-center gap-1.5 text-sm text-[#A0A0A0] active:text-white transition-colors">
                {selectedRuleIds.size === rules.length ? (
                  <><CheckSquare className="w-4 h-4 text-[#FF4655]" /><span>取消全选</span></>
                ) : (
                  <><Square className="w-4 h-4" /><span>全选 ({rules.length})</span></>
                )}
              </button>
              {selectedRuleIds.size > 0 && (
                <div className="flex items-center gap-2">
                  <span className="text-xs text-[#FF4655]">已选择 {selectedRuleIds.size} 条</span>
                  <button
                    onClick={() => {
                      const firstGroupId = groups?.[0]?.id;
                      if (firstGroupId) { setCopyTargetGroupId(firstGroupId); setShowCopyModal(true); }
                    }}
                    className="flex items-center gap-1 px-2.5 py-1.5 bg-[#FF4655] text-white text-xs font-medium rounded-md active:bg-[#E63E4C]"
                  >
                    <Copy className="w-3 h-3" />
                    复制
                  </button>
                  <button
                    onClick={() => {
                      const firstGroupId = groups?.[0]?.id;
                      if (firstGroupId) { setMoveTargetGroupId(firstGroupId); setShowMoveModal(true); }
                    }}
                    className="flex items-center gap-1 px-2.5 py-1.5 bg-[#232323] border border-[#3A3A3A] text-[#A0A0A0] text-xs font-medium rounded-md active:border-[#4A4A4A] active:text-white"
                  >
                    <Move className="w-3 h-3" />
                    移动
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`确定删除选中的 ${selectedRuleIds.size} 条规则？`)) {
                        bulkDeleteRules.mutate({ ruleIds: Array.from(selectedRuleIds) });
                      }
                    }}
                    disabled={bulkDeleteRules.isPending}
                    className="flex items-center gap-1 px-2.5 py-1.5 bg-[#232323] border border-[#FF4655]/30 text-[#FF4655] text-xs font-medium rounded-md active:bg-[#FF4655]/10 disabled:opacity-50"
                  >
                    <Trash2 className="w-3 h-3" />
                    删除
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Rules List */}
          {rules && rules.length > 0 ? (
            <div className="space-y-2">
              {rules.map((rule) => (
                <div
                  key={rule.id}
                  onClick={() => isAuthenticated && toggleRuleSelection(rule.id)}
                  className={`bg-[#1A1A1A] border rounded-lg p-3 transition-all ${
                    isAuthenticated
                      ? selectedRuleIds.has(rule.id)
                        ? "border-[#FF4655] bg-[#FF4655]/5 cursor-pointer"
                        : "border-[#3A3A3A] active:border-[#4A4A4A] cursor-pointer"
                      : "border-[#3A3A3A]"
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {/* Checkbox - only when logged in */}
                    {isAuthenticated && (
                      <div className="flex-shrink-0 mt-0.5" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => toggleRuleSelection(rule.id)}
                          className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${
                            selectedRuleIds.has(rule.id)
                              ? "bg-[#FF4655] border-[#FF4655]"
                              : "border-[#3A3A3A] bg-[#232323]"
                          }`}
                        >
                          {selectedRuleIds.has(rule.id) && <Check className="w-3 h-3 text-white" />}
                        </button>
                      </div>
                    )}

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="text-white font-medium text-sm">{rule.name}</h3>
                        <span className="px-1.5 py-0.5 bg-[#FF4655]/10 text-[#FF4655] text-[10px] rounded">
                          {rule.groupName}
                        </span>
                      </div>
                      <p className="text-[#A0A0A0] text-sm line-clamp-2">{rule.content}</p>
                    </div>

                    {/* Actions - always visible */}
                    <div className="flex items-center gap-1 flex-shrink-0" onClick={(e) => e.stopPropagation()}>
                      {(canEditRule(rule)) && (
                        <button
                          onClick={() => openEdit(rule)}
                          className="p-1.5 rounded hover:bg-[#232323] transition-colors"
                          title="编辑"
                        >
                          <Pencil className="w-4 h-4 text-[#A0A0A0]" />
                        </button>
                      )}
                      {(canDeleteRule(rule)) && (
                        <button
                          onClick={() => { if (confirm("确定删除此规则？")) deleteRule.mutate({ id: rule.id }); }}
                          className="p-1.5 rounded hover:bg-[#FF4655]/20 transition-colors"
                          title="删除"
                        >
                          <Trash2 className="w-4 h-4 text-[#FF4655]" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <FileText className="w-12 h-12 text-[#3A3A3A] mx-auto mb-3" />
              <p className="text-[#A0A0A0] text-sm">
                {search ? "没有找到匹配的规则" : "暂无规则，创建一个吧"}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Create/Edit Rule Modal */}
      {(showCreate || showEdit) && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm">
          <div className="bg-[#1A1A1A] border border-[#3A3A3A] rounded-t-xl sm:rounded-xl p-6 w-full max-w-md sm:mx-4 animate-slide-up">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-white text-xl font-bold">{showEdit ? "编辑规则" : "新建规则"}</h2>
              <button onClick={() => { setShowCreate(false); setShowEdit(null); resetForm(); }} className="p-1 rounded-md hover:bg-[#232323]">
                <X className="w-5 h-5 text-[#A0A0A0]" />
              </button>
            </div>
            <form onSubmit={showEdit ? handleUpdateRule : handleCreateRule} className="space-y-4">
              <div>
                <label className="block text-sm text-[#A0A0A0] mb-1.5">规则名称</label>
                <input type="text" value={ruleName} onChange={(e) => setRuleName(e.target.value)}
                  placeholder="输入规则名称" className="w-full px-3 py-2.5 bg-[#232323] border border-[#3A3A3A] rounded-md text-white placeholder-[#666666] text-sm focus:outline-none focus:border-[#FF4655]" required />
              </div>
              <div>
                <label className="block text-sm text-[#A0A0A0] mb-1.5">规则内容</label>
                <textarea value={ruleContent} onChange={(e) => setRuleContent(e.target.value)}
                  placeholder="输入规则内容" rows={4}
                  className="w-full px-3 py-2.5 bg-[#232323] border border-[#3A3A3A] rounded-md text-white placeholder-[#666666] text-sm focus:outline-none focus:border-[#FF4655] resize-none" required />
              </div>
              <div>
                <label className="block text-sm text-[#A0A0A0] mb-1.5">所属分组</label>
                <select value={ruleGroupId} onChange={(e) => setRuleGroupId(Number(e.target.value))}
                  className="w-full px-3 py-2.5 bg-[#232323] border border-[#3A3A3A] rounded-md text-white text-sm focus:outline-none focus:border-[#FF4655]">
                  {groups?.map((g) => (
                    <option key={g.id} value={g.id}>{g.name}</option>
                  ))}
                </select>
              </div>
              <button type="submit" className="w-full py-2.5 bg-[#FF4655] text-white text-sm font-semibold rounded-md active:bg-[#E63E4C]">
                {showEdit ? "保存" : "创建"}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Create Group Modal */}
      {showCreateGroup && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm">
          <div className="bg-[#1A1A1A] border border-[#3A3A3A] rounded-t-xl sm:rounded-xl p-6 w-full max-w-sm sm:mx-4 animate-slide-up">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-white text-lg font-bold">新建分组</h2>
              <button onClick={() => setShowCreateGroup(false)} className="p-1 rounded-md hover:bg-[#232323]">
                <X className="w-5 h-5 text-[#A0A0A0]" />
              </button>
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (groupName.trim()) createGroup.mutate({ name: groupName.trim() });
              }}
              className="space-y-4"
            >
              <input type="text" value={groupName} onChange={(e) => setGroupName(e.target.value)}
                placeholder="分组名称" className="w-full px-3 py-2.5 bg-[#232323] border border-[#3A3A3A] rounded-md text-white placeholder-[#666666] text-sm focus:outline-none focus:border-[#FF4655]" required />
              <button type="submit" className="w-full py-2.5 bg-[#FF4655] text-white text-sm font-semibold rounded-md active:bg-[#E63E4C]">
                创建
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Edit Group Modal */}
      {editingGroup !== null && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm">
          <div className="bg-[#1A1A1A] border border-[#3A3A3A] rounded-t-xl sm:rounded-xl p-6 w-full max-w-sm sm:mx-4 animate-slide-up">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-white text-lg font-bold">编辑分组</h2>
              <button onClick={() => { setEditingGroup(null); setEditingGroupName(""); }} className="p-1 rounded-md hover:bg-[#232323]">
                <X className="w-5 h-5 text-[#A0A0A0]" />
              </button>
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (editingGroupName.trim()) {
                  updateGroup.mutate({ id: editingGroup, name: editingGroupName.trim() });
                }
              }}
              className="space-y-4"
            >
              <input
                type="text"
                value={editingGroupName}
                onChange={(e) => setEditingGroupName(e.target.value)}
                placeholder="分组名称"
                className="w-full px-3 py-2.5 bg-[#232323] border border-[#3A3A3A] rounded-md text-white placeholder-[#666666] text-sm focus:outline-none focus:border-[#FF4655]"
                required
              />
              <button
                type="submit"
                disabled={updateGroup.isPending}
                className="w-full py-2.5 bg-[#FF4655] text-white text-sm font-semibold rounded-md active:bg-[#E63E4C] disabled:opacity-50"
              >
                {updateGroup.isPending ? "保存中..." : "保存"}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Copy to Group Modal */}
      {showCopyModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm">
          <div className="bg-[#1A1A1A] border border-[#3A3A3A] rounded-t-xl sm:rounded-xl p-6 w-full max-w-sm sm:mx-4 animate-slide-up">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-white text-lg font-bold">复制到分组</h2>
              <button onClick={() => setShowCopyModal(false)} className="p-1 rounded-md hover:bg-[#232323]">
                <X className="w-5 h-5 text-[#A0A0A0]" />
              </button>
            </div>
            <p className="text-[#A0A0A0] text-sm mb-4">已选择 {selectedRuleIds.size} 条规则，选择目标分组：</p>
            <div className="space-y-2 mb-4 max-h-48 overflow-y-auto">
              {groups?.map((g) => (
                <button
                  key={g.id}
                  onClick={() => setCopyTargetGroupId(g.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg border text-sm transition-colors ${
                    copyTargetGroupId === g.id
                      ? "border-[#FF4655] bg-[#FF4655]/10 text-white"
                      : "border-[#3A3A3A] text-[#A0A0A0] hover:border-[#4A4A4A]"
                  }`}
                >
                  <span>{g.name}</span>
                  {copyTargetGroupId === g.id && <Check className="w-4 h-4 text-[#FF4655]" />}
                </button>
              ))}
            </div>
            <button
              onClick={() => {
                if (copyTargetGroupId && selectedRuleIds.size > 0) {
                  copyRules.mutate({
                    ruleIds: Array.from(selectedRuleIds),
                    targetGroupId: copyTargetGroupId,
                  });
                }
              }}
              disabled={!copyTargetGroupId || copyRules.isPending}
              className="w-full py-2.5 bg-[#FF4655] text-white text-sm font-semibold rounded-md active:bg-[#E63E4C] disabled:opacity-50"
            >
              {copyRules.isPending ? "复制中..." : `确认复制 (${selectedRuleIds.size} 条)`}
            </button>
          </div>
        </div>
      )}

      {/* Move to Group Modal */}
      {showMoveModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm">
          <div className="bg-[#1A1A1A] border border-[#3A3A3A] rounded-t-xl sm:rounded-xl p-6 w-full max-w-sm sm:mx-4 animate-slide-up">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-white text-lg font-bold">移动到分组</h2>
              <button onClick={() => setShowMoveModal(false)} className="p-1 rounded-md hover:bg-[#232323]">
                <X className="w-5 h-5 text-[#A0A0A0]" />
              </button>
            </div>
            <p className="text-[#A0A0A0] text-sm mb-4">已选择 {selectedRuleIds.size} 条规则，选择目标分组：</p>
            <div className="space-y-2 mb-4 max-h-48 overflow-y-auto">
              {groups?.map((g) => (
                <button
                  key={g.id}
                  onClick={() => setMoveTargetGroupId(g.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg border text-sm transition-colors ${
                    moveTargetGroupId === g.id
                      ? "border-[#FF4655] bg-[#FF4655]/10 text-white"
                      : "border-[#3A3A3A] text-[#A0A0A0] hover:border-[#4A4A4A]"
                  }`}
                >
                  <span>{g.name}</span>
                  {moveTargetGroupId === g.id && <Check className="w-4 h-4 text-[#FF4655]" />}
                </button>
              ))}
            </div>
            <button
              onClick={() => {
                if (moveTargetGroupId && selectedRuleIds.size > 0) {
                  moveRules.mutate({
                    ruleIds: Array.from(selectedRuleIds),
                    targetGroupId: moveTargetGroupId,
                  });
                }
              }}
              disabled={!moveTargetGroupId || moveRules.isPending}
              className="w-full py-2.5 bg-[#FF4655] text-white text-sm font-semibold rounded-md active:bg-[#E63E4C] disabled:opacity-50"
            >
              {moveRules.isPending ? "移动中..." : `确认移动 (${selectedRuleIds.size} 条)`}
            </button>
          </div>
        </div>
      )}

      {/* Bulk Import Modal */}
      {showBulkImport && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm">
          <div className="bg-[#1A1A1A] border border-[#3A3A3A] rounded-t-xl sm:rounded-xl p-6 w-full max-w-lg sm:mx-4 animate-slide-up">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-white text-lg font-bold">批量导入规则</h2>
              <button onClick={() => setShowBulkImport(false)} className="p-1 rounded-md hover:bg-[#232323]">
                <X className="w-5 h-5 text-[#A0A0A0]" />
              </button>
            </div>
            <form onSubmit={handleBulkImport} className="space-y-4">
              <div>
                <label className="block text-sm text-[#A0A0A0] mb-1.5">目标分组</label>
                <select value={ruleGroupId} onChange={(e) => setRuleGroupId(Number(e.target.value))}
                  className="w-full px-3 py-2.5 bg-[#232323] border border-[#3A3A3A] rounded-md text-white text-sm">
                  {groups?.map((g) => (
                    <option key={g.id} value={g.id}>{g.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm text-[#A0A0A0] mb-1.5">
                  规则列表
                  <span className="text-[#666666] text-xs ml-2">每行一条，格式：规则名称 规则内容</span>
                </label>
                <textarea value={bulkText} onChange={(e) => setBulkText(e.target.value)}
                  placeholder={`强制开镜 | 全程只能开镜射击，禁止腰射
手枪专精 | 只能使用手枪类武器
禁爆头 | 只能攻击身体，禁止爆头击杀`}
                  rows={10}
                  className="w-full px-3 py-2.5 bg-[#232323] border border-[#3A3A3A] rounded-md text-white placeholder-[#666666] text-sm font-mono resize-none" required />
              </div>
              <button type="submit" disabled={bulkImport.isPending}
                className="w-full py-2.5 bg-[#FF4655] text-white text-sm font-semibold rounded-md active:bg-[#E63E4C] disabled:opacity-50">
                {bulkImport.isPending ? "导入中..." : `导入`}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
