import { Link, useLocation } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { Swords, Settings, LogOut, ChevronDown, BookOpen } from "lucide-react";
import { useState, useRef, useEffect } from "react";

export default function Navbar() {
  const { user, isAuthenticated, logout } = useAuth();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 h-14 bg-[#0F0F0F]/95 backdrop-blur-md border-b border-[#3A3A3A]">
      <div className="max-w-7xl mx-auto px-4 h-full flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 group">
          <div className="w-8 h-8 flex items-center justify-center bg-[#FF4655] rounded-sm transform group-hover:scale-105 transition-transform">
            <Swords className="w-5 h-5 text-white" />
          </div>
          <span className="text-white font-bold text-lg tracking-wide hidden sm:block">
            VALORANT<span className="text-[#FF4655]">内战</span>
          </span>
        </Link>

        {/* Nav Links */}
        <div className="flex items-center gap-1">
          <Link
            to="/"
            className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
              isActive("/")
                ? "text-[#FF4655] bg-[#FF4655]/10"
                : "text-[#A0A0A0] hover:text-white hover:bg-[#232323]"
            }`}
          >
            大厅
          </Link>
          <Link
            to="/rules"
            className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
              isActive("/rules")
                ? "text-[#FF4655] bg-[#FF4655]/10"
                : "text-[#A0A0A0] hover:text-white hover:bg-[#232323]"
            }`}
          >
            规则管理
          </Link>
          <Link
            to="/guide"
            className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
              isActive("/guide")
                ? "text-[#FF4655] bg-[#FF4655]/10"
                : "text-[#A0A0A0] hover:text-white hover:bg-[#232323]"
            }`}
          >
            <BookOpen className="w-3.5 h-3.5 inline mr-1 -mt-0.5" />
            指南
          </Link>
        </div>

        {/* User Menu */}
        <div className="flex items-center gap-2" ref={menuRef}>
          {isAuthenticated && user ? (
            <div className="relative">
              <button
                onClick={() => setMenuOpen(!menuOpen)}
                className="flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-[#232323] transition-colors"
              >
                <img
                  src={user.gameAvatar || user.avatar || "/avatars/default-1.jpg"}
                  alt="avatar"
                  className="w-7 h-7 rounded-full object-cover border border-[#3A3A3A]"
                  onError={(e) => { (e.target as HTMLImageElement).src = "/avatars/default-1.jpg"; }}
                />
                <span className="text-sm text-white hidden sm:block max-w-[80px] truncate">
                  {user.nickname || user.name || "用户"}
                </span>
                <ChevronDown className="w-4 h-4 text-[#A0A0A0]" />
              </button>

              {menuOpen && (
                <div className="absolute right-0 top-full mt-1 w-48 bg-[#1A1A1A] border border-[#3A3A3A] rounded-lg shadow-lg py-1 animate-fade-in">
                  <Link
                    to="/settings"
                    onClick={() => setMenuOpen(false)}
                    className="flex items-center gap-2 px-3 py-2 text-sm text-[#A0A0A0] hover:text-white hover:bg-[#232323] transition-colors"
                  >
                    <Settings className="w-4 h-4" />
                    个人设置
                  </Link>
                  <button
                    onClick={() => { logout(); setMenuOpen(false); }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-sm text-[#FF4655] hover:bg-[#FF4655]/10 transition-colors"
                  >
                    <LogOut className="w-4 h-4" />
                    退出登录
                  </button>
                </div>
              )}
            </div>
          ) : (
            <Link
              to="/login"
              className="px-4 py-1.5 bg-[#FF4655] text-white text-sm font-medium rounded-md hover:bg-[#E63E4C] transition-colors"
            >
              登录
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}
